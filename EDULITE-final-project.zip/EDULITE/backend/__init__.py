"""EduLite application backend."""
