import os
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str = "sqlite:///./edulite.db"
    jwt_secret: str = "change-this-secret-before-deployment"
    jwt_expiry_hours: int = Field(default=24, gt=0, le=720)
    gemini_api_key: str = ""
    tesseract_cmd: str = ""
    google_search_api_key: str = ""
    google_search_engine_id: str = ""
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:5500"
    max_upload_mb: int = Field(default=20, gt=0, le=100)
    resource_search_limit: int = Field(default=12, gt=0, le=30)

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def allowed_origins(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def google_search_configured(self) -> bool:
        return bool(self.google_search_api_key and self.google_search_engine_id)


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

if len(settings.jwt_secret) < 32 and settings.jwt_secret != "change-this-secret-before-deployment":
    raise RuntimeError("JWT_SECRET must be at least 32 characters long.")
if os.getenv("ENVIRONMENT", "").lower() == "production" and settings.jwt_secret == "change-this-secret-before-deployment":
    raise RuntimeError("Set a unique JWT_SECRET before running in production.")
