import io
import json
import re
import urllib.error
import urllib.request
from urllib.parse import quote_plus, urlencode, urlparse

from backend.config import settings

TRUSTED_DOMAINS = {
    "geeksforgeeks.org",
    "nptel.ac.in",
    "tutorialspoint.com",
    "javatpoint.com",
    "arxiv.org",
    "github.com",
}


def search_provider() -> str:
    if settings.google_search_configured:
        return "Google Programmable Search"
    if settings.google_search_api_key or settings.google_search_engine_id:
        return "Google Search needs both API key and Search Engine ID"
    return "DuckDuckGo fallback"


def search_resources(topic: str, query: str = "") -> list[dict]:
    search_terms = " ".join(query.split())
    if settings.google_search_api_key or settings.google_search_engine_id:
        if not settings.google_search_configured:
            raise RuntimeError("Configure both GOOGLE_SEARCH_API_KEY and GOOGLE_SEARCH_ENGINE_ID, or clear both to use DuckDuckGo.")
        return _google_search(topic, search_terms)
    return _duckduckgo_search(topic, search_terms)


def _google_search(topic: str, search_terms: str = "") -> list[dict]:
    allowed_sites = " OR ".join(f"site:{domain}" for domain in sorted(TRUSTED_DOMAINS))
    query = f"{topic} {search_terms} free study tutorial notes ({allowed_sites})".strip()
    parameters = urlencode({
        "key": settings.google_search_api_key,
        "cx": settings.google_search_engine_id,
        "q": query,
        "num": min(settings.resource_search_limit, 10),
    })
    request = urllib.request.Request(
        f"https://www.googleapis.com/customsearch/v1?{parameters}",
        headers={"Accept": "application/json", "User-Agent": "EduLiteStudyResources/1.0"},
    )
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            data = json.loads(response.read())
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read()).get("error", {}).get("message", "")
        except (json.JSONDecodeError, AttributeError):
            detail = ""
        raise RuntimeError(
            f"Google Programmable Search returned HTTP {exc.code}"
            + (f": {detail[:300]}" if detail else ". Check the API key, search engine, and API quota.")
        ) from exc
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Google Programmable Search failed: {exc}") from exc
    return _normalize_results(data.get("items", []), topic)


def _duckduckgo_search(topic: str, search_terms: str = "") -> list[dict]:
    from ddgs import DDGS
    from ddgs.exceptions import DDGSException

    query = f"{topic} {search_terms} free study tutorial notes".strip()
    try:
        with DDGS(timeout=12) as search:
            items = search.text(query, max_results=settings.resource_search_limit)
    except DDGSException as exc:
        if str(exc).strip().casefold().rstrip(".") == "no results found":
            return []
        raise RuntimeError(f"DuckDuckGo resource discovery failed: {exc}") from exc
    return _normalize_results(items, topic)


def _normalize_results(items: list[dict], topic: str) -> list[dict]:
    results = []
    seen_urls = set()
    for item in items:
        url = str(item.get("link") or item.get("href") or "")
        try:
            parsed = urlparse(url)
            port = parsed.port
        except ValueError:
            continue
        host = (parsed.hostname or "").lower().removeprefix("www.")
        if (
            parsed.scheme != "https"
            or parsed.username
            or parsed.password
            or port not in (None, 443)
            or not any(host == domain or host.endswith("." + domain) for domain in TRUSTED_DOMAINS)
            or url in seen_urls
        ):
            continue
        seen_urls.add(url)
        snippet = str(item.get("snippet") or item.get("body") or "")[:1200]
        extracted = _extract_page_text(url) if len(results) < 4 else ""
        results.append({
            "title": str(item.get("title") or "Study resource")[:300],
            "url": url,
            "description": (extracted or snippet)[:1200],
            "domain": host,
            "topic": topic,
            "relevance": "Topic match",
        })
        if len(results) >= settings.resource_search_limit:
            break
    return results


def _extract_page_text(url: str) -> str:
    import requests
    from requests import RequestException

    max_bytes = 1_500_000
    try:
        with requests.get(
            url,
            headers={"User-Agent": "EduLiteStudyResources/1.0"},
            timeout=(4, 10),
            allow_redirects=False,
            stream=True,
        ) as response:
            if response.is_redirect or response.status_code >= 400:
                return ""
            content_type = response.headers.get("content-type", "").split(";", 1)[0].lower()
            if response.headers.get("content-length", "").isdigit() and int(response.headers["content-length"]) > max_bytes:
                return ""
            chunks = bytearray()
            for chunk in response.iter_content(chunk_size=32_768):
                chunks.extend(chunk)
                if len(chunks) > max_bytes:
                    return ""
    except RequestException:
        return ""
    if content_type == "application/pdf":
        import pymupdf

        try:
            document = pymupdf.open(stream=bytes(chunks), filetype="pdf")
            return "\n".join(page.get_text("text") for page in document[:5])[:5000]
        except (RuntimeError, ValueError):
            return ""
    if content_type not in {"text/html", "application/xhtml+xml"}:
        return ""
    html = bytes(chunks).decode("utf-8", errors="replace")
    try:
        import trafilatura

        extracted = trafilatura.extract(html, include_comments=False, include_links=False)
        if extracted:
            return extracted[:5000]
    except ImportError:
        pass
    from bs4 import BeautifulSoup

    soup = BeautifulSoup(html, "html.parser")
    for element in soup(["script", "style", "nav", "footer", "header"]):
        element.decompose()
    return soup.get_text(" ", strip=True)[:5000]


def create_study_guide(topic: str, resources: list[dict], syllabus: str) -> str:
    if settings.gemini_api_key:
        prompt = (
            "Write concise, exam-oriented revision notes for the requested topic using the provided syllabus and "
            "resource snippets. Include definitions, key ideas, a worked example or pseudocode where relevant, and "
            "a quick-revision checklist. Do not invent formulas. Attribute factual claims to the provided source "
            "titles or URLs. Return plain text only.\n"
            f"Topic: {topic}\nSyllabus:\n{syllabus[:8000]}\nResources:\n"
            f"{json.dumps(resources[:8], ensure_ascii=False)}"
        )
        request = urllib.request.Request(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
            f"?key={settings.gemini_api_key}",
            data=json.dumps({
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"temperature": 0.3},
            }).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                data = json.loads(response.read())
            content = data["candidates"][0]["content"]["parts"][0]["text"].strip()
            fenced = re.search(r"```(?:markdown)?\s*(.*?)\s*```", content, flags=re.IGNORECASE | re.DOTALL)
            if fenced:
                content = fenced.group(1).strip()
            if len(content) < 80:
                raise RuntimeError("The study-guide model returned incomplete revision notes.")
            return content
        except (urllib.error.URLError, TimeoutError, KeyError, IndexError, json.JSONDecodeError, TypeError, ValueError) as exc:
            raise RuntimeError(f"Gemini study-guide generation failed: {exc}") from exc
    links = "\n".join(f"- {item['title']}: {item['description']}" for item in resources[:5])
    syllabus_points = "\n".join(line for line in syllabus.splitlines() if topic.lower() in line.lower())
    return (
        f"# {topic}: quick revision guide\n\n"
        "## Core ideas\n"
        f"- Define the central terms and explain how they relate to {topic}.\n"
        "- Identify the problem each concept solves and its main assumptions.\n"
        "- Work through one example step by step; check units, edge cases, and the final result.\n\n"
        "## Exam checklist\n"
        "- Start with precise definitions and label diagrams or variables clearly.\n"
        "- Show intermediate reasoning; state assumptions before applying a method.\n"
        "- Compare alternatives using correctness, efficiency, and trade-offs where relevant.\n\n"
        f"## Syllabus focus\n{syllabus_points or f'- Review the syllabus outcomes related to {topic}.'}\n\n"
        f"## Curated reading\n{links or '- No indexed resources were returned. Search the trusted learning sites directly.'}\n"
    )


def trusted_search_url(topic: str, domain: str | None = None, search_terms: str = "") -> str:
    if domain and domain not in TRUSTED_DOMAINS:
        raise ValueError("Google search can only target an allowlisted education domain.")
    sites = f"site:{domain}" if domain else "(" + " OR ".join(
        f"site:{site}" for site in sorted(TRUSTED_DOMAINS)
    ) + ")"
    query = f"{topic} {search_terms} free study notes {sites}".strip()
    return f"https://www.google.com/search?q={quote_plus(query)}"


def youtube_playlist_search_url(topic: str, search_terms: str = "") -> str:
    query = f"{topic} {search_terms} free full course playlist site:youtube.com/playlist".strip()
    return f"https://www.google.com/search?q={quote_plus(query)}"
