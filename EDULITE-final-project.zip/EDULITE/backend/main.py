import json
import re
from pathlib import Path

from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from backend.config import settings
from backend.database import Base, engine, get_db
from backend.export_service import export_paper
from backend.models import Attempt, Paper, Question, Resource, StudyGuide, Subject, User
from backend.resource_service import (
    TRUSTED_DOMAINS,
    create_study_guide,
    search_provider,
    search_resources,
    trusted_search_url,
    youtube_playlist_search_url,
)
from backend.schemas import (
    AttemptRequest,
    BookmarkUpdate,
    Credentials,
    GenerateRequest,
    QuestionImportRequest,
    QuestionUpdate,
    ResourceDiscoveryRequest,
    SubjectCreate,
    TokenResponse,
)
from backend.security import create_access_token, get_current_user, hash_password, verify_password
from ml_pipeline.classification import classify_question, duplicate_groups, family_id_for, get_topics
from ml_pipeline.generation import generate_questions
from ml_pipeline.ingestion import SUPPORTED_FORMATS_LABEL, SUPPORTED_TYPES, extract_text, split_questions
from ml_pipeline.prediction import analyze_patterns, predict_topics

Base.metadata.create_all(bind=engine)
app = FastAPI(title="EduLite API", version="1.0.0", description="PYQ analysis, exam prediction, study resources, and RAG practice papers.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)


def _subject_or_404(db: Session, subject_id: int, user: User) -> Subject:
    subject = db.get(Subject, subject_id)
    if subject is None or (not subject.is_public and subject.user_id != user.id):
        raise HTTPException(status_code=404, detail="Subject not found.")
    return subject


def _questions_for(db: Session, subject: Subject, user: User) -> list[Question]:
    return list(db.scalars(
        select(Question)
        .where(
            Question.subject_id == subject.id,
            or_(Question.owner_id == user.id, (Question.owner_id.is_(None) & Subject.is_public)),
        )
        .join(Subject)
        .order_by(Question.year, Question.id)
    ).all())


def _paper_or_404(db: Session, paper_id: int, user: User) -> tuple[Paper, dict]:
    paper = db.get(Paper, paper_id)
    if paper is None or paper.user_id != user.id:
        raise HTTPException(status_code=404, detail="Practice paper not found.")
    return paper, json.loads(paper.content)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "EduLite API"}


@app.post("/api/auth/register", response_model=TokenResponse, status_code=201)
def register(payload: Credentials, db: Session = Depends(get_db)):
    email = str(payload.email).strip().lower()
    user = User(email=email, password_hash=hash_password(payload.password))
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An account with that email already exists.") from None
    return TokenResponse(access_token=create_access_token(user.id))


@app.post("/api/auth/login", response_model=TokenResponse)
def login(payload: Credentials, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == str(payload.email).strip().lower()))
    if user is None or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    return TokenResponse(access_token=create_access_token(user.id))


@app.get("/api/auth/me")
def me(user: User = Depends(get_current_user)):
    return {"id": user.id, "email": user.email}


@app.get("/api/subjects")
def list_subjects(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subjects = db.scalars(
        select(Subject).where(or_(Subject.is_public.is_(True), Subject.user_id == user.id)).order_by(Subject.name)
    ).all()
    return [{"id": item.id, "name": item.name, "syllabus": item.syllabus, "is_public": item.is_public} for item in subjects]


@app.post("/api/subjects", status_code=201)
def create_subject(payload: SubjectCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subject = Subject(name=payload.name.strip(), syllabus=payload.syllabus.strip(), user_id=user.id)
    db.add(subject)
    db.commit()
    db.refresh(subject)
    return {"id": subject.id, "name": subject.name, "syllabus": subject.syllabus, "is_public": False}


@app.get("/api/subjects/{subject_id}/questions")
def list_questions(subject_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subject = _subject_or_404(db, subject_id, user)
    questions = _questions_for(db, subject, user)
    groups = duplicate_groups(questions)
    duplicate_ids = {question_id for group in groups for question_id in group}
    return {
        "questions": [
            {
                "id": item.id,
                "text": item.text,
                "year": item.year,
                "topic": item.topic,
                "marks": item.marks,
                "difficulty": item.difficulty,
                "question_type": item.question_type,
                "confidence": item.confidence,
                "needs_review": item.confidence < 0.6,
                "family_id": item.family_id,
                "is_duplicate": item.id in duplicate_ids,
                "source": item.source,
            }
            for item in questions
        ],
        "duplicate_groups": groups,
    }


@app.post("/api/subjects/{subject_id}/upload", status_code=201)
def upload_pyqs(
    subject_id: int,
    files: list[UploadFile] = File(...),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    subject = _subject_or_404(db, subject_id, user)
    if not files or len(files) > 20:
        raise HTTPException(status_code=400, detail="Upload between 1 and 20 files at a time.")
    preview = []
    for upload in files:
        filename = Path(upload.filename or "upload").name
        if Path(filename).suffix.lower() not in SUPPORTED_TYPES:
            raise HTTPException(
                status_code=415,
                detail=f"Unsupported file '{filename}'. Supported formats: {SUPPORTED_FORMATS_LABEL}.",
            )
        content = upload.file.read(settings.max_upload_mb * 1024 * 1024 + 1)
        if len(content) > settings.max_upload_mb * 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"'{filename}' exceeds the {settings.max_upload_mb} MB file limit.")
        try:
            text = extract_text(filename, content)
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        segments, year = split_questions(text, filename)
        if not segments:
            raise HTTPException(status_code=422, detail=f"No questions could be extracted from '{filename}'.")
        if len(preview) + len(segments) > 300:
            raise HTTPException(status_code=413, detail="A review batch is limited to 300 questions. Upload fewer papers at a time.")
        for segment in segments:
            classified = classify_question(segment["text"], subject)
            preview.append({
                "text": segment["text"],
                "year": segment["year"] or year,
                "topic": classified["topic"],
                "marks": segment["marks"],
                "difficulty": classified["difficulty"],
                "question_type": classified["question_type"],
                "confidence": min(segment["confidence"], classified["confidence"]),
                "source": filename[:255],
            })
    return {
        "message": f"Extracted {len(preview)} questions. Review and save the preview to add them to your library.",
        "questions": [
            {**question, "preview_id": index, "needs_review": question["confidence"] < 0.6}
            for index, question in enumerate(preview)
        ],
    }


@app.post("/api/subjects/{subject_id}/questions/import", status_code=201)
def import_reviewed_questions(
    subject_id: int,
    payload: QuestionImportRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    subject = _subject_or_404(db, subject_id, user)
    valid_topics = set(get_topics(subject))
    invalid_topics = {item.topic for item in payload.questions if item.topic not in valid_topics}
    if invalid_topics:
        raise HTTPException(status_code=422, detail=f"Topics must match this subject's syllabus: {', '.join(sorted(invalid_topics))}")
    imported = [
        Question(
            subject_id=subject.id,
            owner_id=user.id,
            text=item.text,
            year=item.year,
            topic=item.topic,
            marks=item.marks,
            difficulty=item.difficulty,
            question_type=item.question_type,
            confidence=1.0,
            source=item.source,
            family_id=family_id_for(item.text),
        )
        for item in payload.questions
    ]
    db.add_all(imported)
    db.commit()
    return {"message": f"Saved {len(imported)} reviewed questions.", "count": len(imported)}


@app.put("/api/questions/{question_id}")
def update_question(
    question_id: int,
    payload: QuestionUpdate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    question = db.get(Question, question_id)
    if question is None or question.owner_id != user.id:
        raise HTTPException(status_code=404, detail="Editable question not found.")
    for key, value in payload.model_dump().items():
        setattr(question, key, value)
    question.confidence = 1.0
    question.family_id = family_id_for(question.text)
    db.commit()
    return {"id": question.id, "message": "Question review saved."}


@app.get("/api/subjects/{subject_id}/analytics")
def analytics(subject_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subject = _subject_or_404(db, subject_id, user)
    questions = _questions_for(db, subject, user)
    return analyze_patterns(questions, get_topics(subject))


@app.get("/api/subjects/{subject_id}/predictions")
def predictions(subject_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subject = _subject_or_404(db, subject_id, user)
    predictions_data = predict_topics(_questions_for(db, subject, user), get_topics(subject))
    return {
        "notice": "Predictions are estimates from the available papers, not guarantees.",
        "predictions": predictions_data,
    }


@app.get("/api/subjects/{subject_id}/recommendations")
def recommendations(subject_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subject = _subject_or_404(db, subject_id, user)
    papers = db.scalars(select(Paper).where(Paper.subject_id == subject.id, Paper.user_id == user.id)).all()
    paper_data = {paper.id: json.loads(paper.content) for paper in papers}
    attempts = db.scalars(select(Attempt).where(
        Attempt.user_id == user.id,
        Attempt.paper_id.in_(paper_data.keys()) if paper_data else False,
    )).all()
    weak: dict[str, dict[str, int]] = {}
    for attempt in attempts:
        paper = paper_data.get(attempt.paper_id)
        if not paper or not (attempt.is_correct is False or (attempt.self_rating is not None and attempt.self_rating <= 2)):
            continue
        question = paper["questions"][attempt.question_number - 1]
        topic = question["topic"]
        counts = weak.setdefault(topic, {"needs_practice": 0, "attempts": 0})
        counts["needs_practice"] += 1
        counts["attempts"] += 1
    return {
        "recommendations": [
            {"topic": topic, **counts, "suggestion": f"Review the guide and try another practice question in {topic}."}
            for topic, counts in sorted(weak.items(), key=lambda item: item[1]["needs_practice"], reverse=True)
        ]
    }


@app.get("/api/subjects/{subject_id}/question-families")
def families(subject_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subject = _subject_or_404(db, subject_id, user)
    questions = _questions_for(db, subject, user)
    by_id = {q.id: q for q in questions}
    return [
        [{"id": question_id, "text": by_id[question_id].text, "topic": by_id[question_id].topic} for question_id in group]
        for group in duplicate_groups(questions)
    ]


@app.post("/api/subjects/{subject_id}/papers", status_code=201)
def create_paper(
    subject_id: int,
    payload: GenerateRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    subject = _subject_or_404(db, subject_id, user)
    available_topics = get_topics(subject)
    custom_topic = payload.custom_topic.strip()
    custom_topic_key = custom_topic.casefold()
    requested_topics = list(dict.fromkeys(topic.strip() for topic in payload.topics if topic.strip()))
    invalid = [
        topic for topic in requested_topics
        if topic not in available_topics and topic.casefold() != custom_topic_key
    ]
    if invalid:
        raise HTTPException(status_code=422, detail=f"Topics must match this subject's syllabus: {', '.join(invalid)}")
    topics = list(dict.fromkeys(requested_topics + ([custom_topic] if custom_topic else [])))
    if not topics:
        raise HTTPException(status_code=422, detail="Choose a syllabus topic or enter a custom computer topic.")
    if len(topics) > 10:
        raise HTTPException(status_code=422, detail="Choose no more than 10 topics at a time.")
    try:
        generated = generate_questions(
            subject,
            _questions_for(db, subject, user),
            topics,
            payload.question_count,
            payload.marks_per_question,
            payload.question_type,
            payload.difficulty,
            [
                {"title": resource.title, "description": resource.description, "url": resource.url}
                for resource in db.scalars(select(Resource).where(
                    Resource.subject_id == subject.id,
                    Resource.user_id == user.id,
                    Resource.topic.in_(topics),
                )).all()
            ],
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    paper_data = {
        "title": f"{subject.name} — EduLite practice paper",
        "questions": generated,
        "notice": "Original AI-assisted practice; probability estimates are not exam guarantees.",
        "study_guides": [
            {"topic": guide.topic, "content": guide.content}
            for guide in db.scalars(select(StudyGuide).where(
                StudyGuide.subject_id == subject.id,
                StudyGuide.user_id == user.id,
                StudyGuide.topic.in_(topics),
            )).all()
        ],
    }
    paper = Paper(subject_id=subject.id, user_id=user.id, title=paper_data["title"], content=json.dumps(paper_data))
    db.add(paper)
    db.commit()
    db.refresh(paper)
    return {"id": paper.id, **paper_data, "created_at": paper.created_at.isoformat()}


@app.get("/api/papers")
def list_papers(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    papers = db.scalars(select(Paper).where(Paper.user_id == user.id).order_by(Paper.created_at.desc())).all()
    return [{"id": paper.id, "title": paper.title, "created_at": paper.created_at.isoformat()} for paper in papers]


@app.get("/api/papers/{paper_id}")
def get_paper(paper_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    paper, data = _paper_or_404(db, paper_id, user)
    data["id"] = paper.id
    return data


@app.get("/api/papers/{paper_id}/export")
def download_paper(
    paper_id: int,
    format: str = "pdf",
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _, data = _paper_or_404(db, paper_id, user)
    try:
        content, content_type, suffix = export_paper(data, format.lower())
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    filename = re.sub(r"[^a-zA-Z0-9_-]+", "-", data["title"]).strip("-") or "edulite-practice"
    return Response(
        content,
        media_type=content_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}{suffix}"'},
    )


@app.post("/api/papers/{paper_id}/attempt")
def submit_attempt(
    paper_id: int,
    payload: AttemptRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    paper, data = _paper_or_404(db, paper_id, user)
    number = payload.question_id
    if number < 1 or number > len(data["questions"]):
        raise HTTPException(status_code=404, detail="Question number not found in this paper.")
    question = data["questions"][number - 1]
    is_correct = None
    if question.get("question_type") == "MCQ":
        is_correct = payload.answer.strip().upper() == str(question.get("correct_option", "")).upper()
    attempt = Attempt(
        paper_id=paper.id,
        user_id=user.id,
        question_number=number,
        response=payload.answer,
        self_rating=payload.self_evaluation,
        is_correct=is_correct,
    )
    db.add(attempt)
    db.commit()
    response = {"saved": True, "is_correct": is_correct}
    if question.get("question_type") != "MCQ":
        response["model_answer"] = question["answer"]
    return response


@app.get("/api/subjects/{subject_id}/resources")
def list_resources(
    subject_id: int,
    topic: str | None = None,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    subject = _subject_or_404(db, subject_id, user)
    query = select(Resource).where(Resource.subject_id == subject_id, Resource.user_id == user.id)
    if topic:
        query = query.where(Resource.topic == topic)
    rows = db.scalars(query.order_by(Resource.created_at.desc())).all()
    return [{"id": row.id, "topic": row.topic, "title": row.title, "url": row.url, "description": row.description, "domain": row.domain, "bookmarked": row.bookmarked} for row in rows]


@app.get("/api/search/status")
def search_status(user: User = Depends(get_current_user)):
    return {
        "provider": search_provider(),
        "google_api_enabled": settings.google_search_configured,
        "direct_google_search_available": True,
    }


@app.post("/api/subjects/{subject_id}/resources/discover")
def discover_resources(
    subject_id: int,
    payload: ResourceDiscoveryRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    subject = _subject_or_404(db, subject_id, user)
    topic = payload.topic.strip()
    search_terms = " ".join(payload.query.split())
    if not topic:
        raise HTTPException(status_code=422, detail="Enter a subject topic to find study resources.")
    try:
        found = search_resources(topic, search_terms)
    except (ImportError, OSError, RuntimeError, TimeoutError) as exc:
        raise HTTPException(status_code=502, detail=f"Trusted-source search failed: {exc}") from exc
    for item in found:
        duplicate = db.scalar(select(Resource).where(
            Resource.subject_id == subject.id, Resource.user_id == user.id, Resource.url == item["url"]
        ))
        if duplicate is None:
            db.add(Resource(
                subject_id=subject.id,
                user_id=user.id,
                topic=topic,
                title=item["title"],
                url=item["url"],
                description=item["description"],
                domain=item["domain"],
            ))
    try:
        guide_content = create_study_guide(topic, found, subject.syllabus)
    except RuntimeError as exc:
        db.rollback()
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    guide = db.scalar(select(StudyGuide).where(
        StudyGuide.subject_id == subject.id, StudyGuide.user_id == user.id, StudyGuide.topic == topic
    ))
    if guide is None:
        guide = StudyGuide(subject_id=subject.id, user_id=user.id, topic=topic, content=guide_content)
        db.add(guide)
    else:
        guide.content = guide_content
    db.commit()
    return {
        "topic": topic,
        "resources": found,
        "search_provider": search_provider(),
        "google_search_url": trusted_search_url(topic, search_terms=search_terms),
        "youtube_playlist_search_url": youtube_playlist_search_url(topic, search_terms=search_terms),
        "study_guide": guide_content,
        "trusted_domains": sorted(TRUSTED_DOMAINS),
        "fallback_searches": [trusted_search_url(topic, domain) for domain in sorted(TRUSTED_DOMAINS)] if not found else [],
    }


@app.get("/api/subjects/{subject_id}/study-guides")
def list_study_guides(subject_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _subject_or_404(db, subject_id, user)
    guides = db.scalars(select(StudyGuide).where(StudyGuide.subject_id == subject_id, StudyGuide.user_id == user.id)).all()
    return [{"topic": guide.topic, "content": guide.content} for guide in guides]


@app.get("/api/subjects/{subject_id}/study-guides/export")
def export_study_guides(
    subject_id: int,
    format: str = "pdf",
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    subject = _subject_or_404(db, subject_id, user)
    guides = db.scalars(select(StudyGuide).where(
        StudyGuide.subject_id == subject_id,
        StudyGuide.user_id == user.id,
    ).order_by(StudyGuide.topic)).all()
    if not guides:
        raise HTTPException(status_code=404, detail="Generate or save a study guide before exporting notes.")
    try:
        content, content_type, suffix = export_paper({
            "title": f"{subject.name} revision notes",
            "questions": [],
            "study_guides": [{"topic": guide.topic, "content": guide.content} for guide in guides],
        }, format.lower())
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return Response(
        content,
        media_type=content_type,
        headers={"Content-Disposition": f'attachment; filename="edulite-revision-notes{suffix}"'},
    )


@app.put("/api/resources/{resource_id}/bookmark")
def update_bookmark(
    resource_id: int,
    payload: BookmarkUpdate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    resource = db.get(Resource, resource_id)
    if resource is None or resource.user_id != user.id:
        raise HTTPException(status_code=404, detail="Study resource not found.")
    resource.bookmarked = payload.bookmarked
    db.commit()
    return {"id": resource.id, "bookmarked": resource.bookmarked}
