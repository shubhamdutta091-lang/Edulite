from io import BytesIO
from pathlib import Path


def export_paper(paper: dict, file_format: str) -> tuple[bytes, str, str]:
    if file_format == "pdf":
        try:
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont
            from reportlab.lib.pagesizes import letter
            from reportlab.pdfgen import canvas
        except ImportError as exc:
            raise RuntimeError("PDF export requires reportlab. Install the backend requirements.") from exc
        stream = BytesIO()
        pdf = canvas.Canvas(stream, pagesize=letter)
        _, height = letter
        font_candidates = [
            Path("C:/Windows/Fonts/arial.ttf"),
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"),
        ]
        font_path = next((path for path in font_candidates if path.is_file()), None)
        font_name = "Helvetica"
        if font_path:
            pdfmetrics.registerFont(TTFont("EduLiteUnicode", str(font_path)))
            font_name = "EduLiteUnicode"
        pdf.setFont(font_name, 10)
        y = height - 48

        def line(text: str, leading: int = 15):
            nonlocal y
            for segment in _wrap(text, 95):
                if y < 48:
                    pdf.showPage()
                    pdf.setFont(font_name, 10)
                    y = height - 48
                pdf.drawString(48, y, segment)
                y -= leading

        line(paper.get("title", "EduLite Practice Paper"), 22)
        for question in paper.get("questions", []):
            line(
                f"{question['question_number']}. [{question['topic']} | {question['question_type']} | "
                f"{question['difficulty']} | {question['marks']} marks]"
            )
            line(question["question"])
            for option in question.get("options", []):
                line(option)
            line(f"Model answer: {question['answer']}")
            line("Mark scheme: " + "; ".join(f"{part['criterion']} ({part['marks']})" for part in question.get("mark_scheme", [])))
            if question.get("citations"):
                line("Sources: " + "; ".join(question["citations"]))
            y -= 10
        for guide in paper.get("study_guides", []):
            y -= 10
            line(f"Revision notes — {guide['topic']}", 18)
            for note_line in guide["content"].splitlines():
                line(note_line)
        pdf.save()
        return stream.getvalue(), "application/pdf", ".pdf"
    if file_format == "docx":
        try:
            from docx import Document
        except ImportError as exc:
            raise RuntimeError("Word export requires python-docx. Install the backend requirements.") from exc
        document = Document()
        document.add_heading(paper.get("title", "EduLite Practice Paper"), level=0)
        for question in paper.get("questions", []):
            document.add_heading(
                f"Question {question['question_number']} — {question['topic']} "
                f"({question['question_type']}, {question['difficulty']})",
                level=2,
            )
            document.add_paragraph(f"{question['question']} ({question['marks']} marks)")
            for option in question.get("options", []):
                document.add_paragraph(option, style="List Bullet")
            document.add_heading("Model answer", level=3)
            document.add_paragraph(question["answer"])
            document.add_heading("Mark scheme", level=3)
            for item in question.get("mark_scheme", []):
                document.add_paragraph(f"{item['criterion']}: {item['marks']} marks", style="List Bullet")
            if question.get("citations"):
                document.add_paragraph("Sources: " + "; ".join(question["citations"]))
        for guide in paper.get("study_guides", []):
            document.add_page_break()
            document.add_heading(f"Revision notes — {guide['topic']}", level=1)
            for line in guide["content"].splitlines():
                if line.startswith("# "):
                    document.add_heading(line[2:], level=2)
                elif line.startswith("## "):
                    document.add_heading(line[3:], level=3)
                else:
                    document.add_paragraph(line)
        stream = BytesIO()
        document.save(stream)
        return stream.getvalue(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx"
    raise ValueError("Format must be pdf or docx.")


def _wrap(text: str, limit: int) -> list[str]:
    words = text.split()
    lines, current = [], ""
    for word in words:
        if len(current) + len(word) + 1 > limit:
            lines.append(current)
            current = word
        else:
            current = f"{current} {word}".strip()
    if current:
        lines.append(current)
    return lines
