from sqlalchemy import select

from backend.database import Base, SessionLocal, engine
from backend.models import Question, Subject
from ml_pipeline.classification import DEFAULT_TOPICS, family_id_for

SAMPLE_TEXTS = {
    "Data Structures": [
        "Trace insertion and deletion in a linked list and analyze the time complexity.",
        "Compare breadth-first search and depth-first search on a graph.",
        "Explain how a balanced binary search tree maintains logarithmic operations.",
        "Use a stack to evaluate a postfix expression and show each intermediate state.",
        "Compare merge sort and quicksort, including their best and worst-case behavior.",
    ],
    "DBMS": [
        "Normalize a relation to third normal form and explain the functional dependencies.",
        "Explain transaction isolation and demonstrate a dirty read schedule.",
        "Write a SQL query that joins two relations and groups the resulting records.",
        "Compare clustered and non-clustered indexes for a read-heavy workload.",
        "Design an ER model for a small library lending system.",
    ],
    "Operating Systems": [
        "Compare preemptive and non-preemptive CPU scheduling using a worked example.",
        "Explain virtual memory and calculate the effective address for a page reference.",
        "Describe the necessary conditions for deadlock and a prevention strategy.",
        "Trace a producer-consumer solution using semaphores.",
        "Compare paging and segmentation with respect to fragmentation.",
    ],
    "Computer Networks": [
        "Compare the OSI model with the TCP/IP model and map their layers.",
        "Explain how a TCP connection is established and terminated.",
        "Use a routing example to compare distance-vector and link-state approaches.",
        "Calculate the subnet range and usable host count for a given CIDR prefix.",
        "Describe error detection using a checksum and discuss its limitations.",
    ],
}


def seed_database() -> int:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    inserted = 0
    try:
        for name, topics in DEFAULT_TOPICS.items():
            syllabus = "\n".join(topics)
            subject = db.scalar(select(Subject).where(Subject.name == name, Subject.is_public.is_(True)))
            if subject is None:
                subject = Subject(name=name, syllabus=syllabus, is_public=True)
                db.add(subject)
                db.flush()
            elif not subject.syllabus:
                subject.syllabus = syllabus
            existing = db.scalar(select(Question.id).where(Question.subject_id == subject.id).limit(1))
            if existing is not None:
                continue
            for year_index, year in enumerate(range(2019, 2025)):
                for question_index in range(3):
                    template = SAMPLE_TEXTS[name][(year_index + question_index) % len(SAMPLE_TEXTS[name])]
                    text = f"Q{question_index + 1}. {template}"
                    db.add(Question(
                        subject_id=subject.id,
                        owner_id=None,
                        text=text,
                        year=year,
                        topic=topics[(year_index + question_index) % len(topics)],
                        marks=float((question_index + 1) * 2 + 2),
                        difficulty=("Easy", "Medium", "Hard")[(year_index + question_index) % 3],
                        question_type=("Short Answer", "Long Answer", "Numerical")[(year_index + question_index) % 3],
                        confidence=0.93,
                        source="synthetic sample dataset",
                        family_id=family_id_for(text),
                    ))
                    inserted += 1
        db.commit()
        return inserted
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    count = seed_database()
    print(f"Seeded {count} sample questions across the available subjects.")
