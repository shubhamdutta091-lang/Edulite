from pydantic import BaseModel, ConfigDict, EmailStr, Field


class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class SubjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    syllabus: str = Field(default="", max_length=100_000)


class SubjectResponse(BaseModel):
    id: int
    name: str
    syllabus: str
    is_public: bool

    model_config = ConfigDict(from_attributes=True)


class QuestionUpdate(BaseModel):
    text: str = Field(min_length=5, max_length=10_000)
    topic: str = Field(min_length=1, max_length=160)
    year: int | None = Field(default=None, ge=1900, le=2200)
    marks: float | None = Field(default=None, ge=0, le=100)
    difficulty: str = Field(pattern="^(Easy|Medium|Hard)$")
    question_type: str = Field(pattern="^(MCQ|Short Answer|Long Answer|Numerical|Code)$")


class QuestionImportItem(QuestionUpdate):
    source: str = Field(min_length=1, max_length=255)


class QuestionImportRequest(BaseModel):
    questions: list[QuestionImportItem] = Field(min_length=1, max_length=300)


class GenerateRequest(BaseModel):
    topics: list[str] = Field(default_factory=list, max_length=10)
    custom_topic: str = Field(default="", max_length=160)
    question_count: int = Field(default=5, ge=1, le=20)
    marks_per_question: float = Field(default=5, gt=0, le=100)
    question_type: str = Field(default="Long Answer", pattern="^(Any|MCQ|Short Answer|Long Answer|Numerical|Code)$")
    difficulty: str = Field(default="Medium", pattern="^(Easy|Medium|Hard)$")


class AttemptRequest(BaseModel):
    question_id: int
    answer: str = Field(max_length=10_000)
    self_evaluation: int | None = Field(default=None, ge=1, le=5)


class BookmarkUpdate(BaseModel):
    bookmarked: bool


class ResourceDiscoveryRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=160)
    query: str = Field(default="", max_length=200)
