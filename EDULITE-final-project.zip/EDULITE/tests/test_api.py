from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import backend.main as api_module
from backend.database import Base, get_db
from backend.main import app


def auth_headers(response):
    return {"Authorization": " ".join(("Bearer", response.json()["access_token"]))}


@pytest.fixture
def client():
    test_engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    TestingSession = sessionmaker(bind=test_engine, autoflush=False, expire_on_commit=False)
    Base.metadata.create_all(bind=test_engine)

    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
    Base.metadata.drop_all(bind=test_engine)
    test_engine.dispose()


def test_auth_subject_upload_analytics_and_paper_workflow(client):
    registration = client.post("/api/auth/register", json={
        "email": "student@example.com",
        "password": "a-strong-password",
    })
    assert registration.status_code == 201
    headers = {"Authorization": f"Bearer {registration.json()['access_token']}"}

    subject_response = client.post("/api/subjects", headers=headers, json={
        "name": "Data Structures",
        "syllabus": "Trees and Graphs\nSorting and Searching",
    })
    assert subject_response.status_code == 201
    subject_id = subject_response.json()["id"]

    uploaded = client.post(
        f"/api/subjects/{subject_id}/upload",
        headers=headers,
        files=[("files", ("paper-2024.txt", b"Q1. Explain graph traversal with an example. [5 marks]\n\nQ2. Compare sorting methods and analyze complexity. [10 marks]", "text/plain"))],
    )
    assert uploaded.status_code == 201
    assert len(uploaded.json()["questions"]) == 2
    assert all("preview_id" in item for item in uploaded.json()["questions"])
    assert client.get(f"/api/subjects/{subject_id}/analytics", headers=headers).json()["total_questions"] == 0

    imported = client.post(
        f"/api/subjects/{subject_id}/questions/import",
        headers=headers,
        json={"questions": [
            {key: item[key] for key in ("text", "year", "topic", "marks", "difficulty", "question_type", "source")}
            for item in uploaded.json()["questions"]
        ]},
    )
    assert imported.status_code == 201
    assert imported.json()["count"] == 2

    analytics = client.get(f"/api/subjects/{subject_id}/analytics", headers=headers)
    assert analytics.status_code == 200
    assert analytics.json()["years"] == [2024]

    generated = client.post(f"/api/subjects/{subject_id}/papers", headers=headers, json={
        "topics": ["Trees and Graphs"],
        "question_count": 1,
        "marks_per_question": 5,
        "question_type": "MCQ",
        "difficulty": "Medium",
    })
    assert generated.status_code == 201
    paper = generated.json()
    attempt = client.post(f"/api/papers/{paper['id']}/attempt", headers=headers, json={
        "question_id": 1,
        "answer": paper["questions"][0]["correct_option"],
    })
    assert attempt.status_code == 200
    assert attempt.json()["is_correct"] is True
    pdf = client.get(f"/api/papers/{paper['id']}/export?format=pdf", headers=headers)
    docx = client.get(f"/api/papers/{paper['id']}/export?format=docx", headers=headers)
    assert pdf.status_code == 200 and pdf.content.startswith(b"%PDF")
    assert docx.status_code == 200 and docx.content.startswith(b"PK")


def test_private_subject_is_not_visible_to_other_users(client):
    first = client.post("/api/auth/register", json={"email": "first@example.com", "password": "a-strong-password"}).json()
    second = client.post("/api/auth/register", json={"email": "second@example.com", "password": "another-strong-password"}).json()
    own_subject = client.post(
        "/api/subjects",
        headers={"Authorization": f"Bearer {first['access_token']}"},
        json={"name": "Private Subject", "syllabus": "Topic A"},
    ).json()
    result = client.get(
        f"/api/subjects/{own_subject['id']}/analytics",
        headers={"Authorization": f"Bearer {second['access_token']}"},
    )
    assert result.status_code == 404


def test_practice_paper_accepts_a_custom_computer_topic(client, monkeypatch):
    registration = client.post("/api/auth/register", json={
        "email": "custom-topic@example.com",
        "password": "a-strong-password",
    })
    headers = auth_headers(registration)
    subject = client.post("/api/subjects", headers=headers, json={
        "name": "Computer Science",
        "syllabus": "Programming fundamentals",
    }).json()
    rejected = client.post(f"/api/subjects/{subject['id']}/papers", headers=headers, json={
        "topics": ["Operating systems"],
        "question_type": "Numerical",
    })
    assert rejected.status_code == 422

    generated_topics = []

    def fake_generate_questions(subject, questions, topics, count, marks, question_type, difficulty, external_context):
        generated_topics.extend(topics)
        return [{
            "question_number": 1,
            "question": "Solve this binary subtraction problem and show each step.",
            "answer": "Convert the values to binary, subtract, and verify the result.",
            "topic": topics[0],
            "marks": marks,
            "difficulty": difficulty,
            "question_type": question_type,
        }]

    monkeypatch.setattr(api_module, "generate_questions", fake_generate_questions)
    response = client.post(f"/api/subjects/{subject['id']}/papers", headers=headers, json={
        "custom_topic": "Binary subtraction",
        "question_count": 1,
        "marks_per_question": 5,
        "question_type": "Numerical",
        "difficulty": "Medium",
    })

    assert response.status_code == 201
    assert generated_topics == ["Binary subtraction"]
    assert response.json()["questions"][0]["topic"] == "Binary subtraction"


def test_rejects_unauthenticated_private_api(client):
    response = client.get("/api/subjects")
    assert response.status_code == 401


def test_docx_upload_requires_confirmation_before_persisting_questions(client):
    from io import BytesIO
    from docx import Document

    registration = client.post("/api/auth/register", json={
        "email": "docx-upload@example.com",
        "password": "a-strong-password",
    })
    headers = auth_headers(registration)
    subject = client.post("/api/subjects", headers=headers, json={
        "name": "Data Structures",
        "syllabus": "Trees and Graphs",
    }).json()

    document = Document()
    document.add_paragraph("Q1. Explain graph traversal with an example. [5 marks]")
    file_content = BytesIO()
    document.save(file_content)
    uploaded = client.post(
        f"/api/subjects/{subject['id']}/upload",
        headers=headers,
        files=[("files", ("paper-2024.docx", file_content.getvalue(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))],
    )
    assert uploaded.status_code == 201
    assert len(uploaded.json()["questions"]) == 1
    assert client.get(
        f"/api/subjects/{subject['id']}/questions",
        headers=headers,
    ).json()["questions"] == []

    saved = client.post(
        f"/api/subjects/{subject['id']}/questions/import",
        headers=headers,
        json={"questions": [
            {key: item[key] for key in ("text", "year", "topic", "marks", "difficulty", "question_type", "source")}
            for item in uploaded.json()["questions"]
        ]},
    )
    assert saved.status_code == 201
    assert saved.json()["count"] == 1
    assert len(client.get(
        f"/api/subjects/{subject['id']}/questions",
        headers=headers,
    ).json()["questions"]) == 1


def test_upload_rejects_unsupported_files_with_supported_format_list(client):
    registration = client.post("/api/auth/register", json={
        "email": "unsupported-upload@example.com",
        "password": "a-strong-password",
    })
    headers = auth_headers(registration)
    subject = client.post("/api/subjects", headers=headers, json={
        "name": "Data Structures",
        "syllabus": "Trees and Graphs",
    }).json()
    response = client.post(
        f"/api/subjects/{subject['id']}/upload",
        headers=headers,
        files=[("files", ("paper.doc", b"legacy word document", "application/msword"))],
    )
    assert response.status_code == 415
    assert "DOCX" in response.json()["detail"]
    assert "TIFF" in response.json()["detail"]


def test_scanned_image_upload_uses_builtin_ocr_when_tesseract_is_missing(client, monkeypatch):
    from io import BytesIO
    from PIL import Image
    import ml_pipeline.ingestion as ingestion

    monkeypatch.delenv("TESSERACT_CMD", raising=False)
    monkeypatch.setattr(ingestion.settings, "tesseract_cmd", "")
    monkeypatch.setattr(ingestion.shutil, "which", lambda command: None)
    monkeypatch.setattr(ingestion.Path, "is_file", lambda path: False)
    monkeypatch.setattr(ingestion, "_rapidocr_image_to_string", lambda image: "Q1. Explain tree traversal and give an example. [5 marks]")

    registration = client.post("/api/auth/register", json={
        "email": "ocr-upload@example.com",
        "password": "a-strong-password",
    })
    headers = auth_headers(registration)
    subject = client.post("/api/subjects", headers=headers, json={
        "name": "Image OCR",
        "syllabus": "Trees and Graphs",
    }).json()
    image = Image.new("RGB", (40, 40), "white")
    image_bytes = BytesIO()
    image.save(image_bytes, format="PNG")

    response = client.post(
        f"/api/subjects/{subject['id']}/upload",
        headers=headers,
        files=[("files", ("scan.png", image_bytes.getvalue(), "image/png"))],
    )
    assert response.status_code == 201
    assert len(response.json()["questions"]) == 1
    assert response.json()["questions"][0]["marks"] == 5


def test_login_accepts_registered_credentials_and_rejects_invalid_password(client):
    registration = client.post("/api/auth/register", json={
        "email": "login@example.com",
        "password": "a-strong-password",
    })
    assert registration.status_code == 201

    login = client.post("/api/auth/login", json={
        "email": "LOGIN@example.com",
        "password": "a-strong-password",
    })
    assert login.status_code == 200
    assert login.json()["access_token"]
    assert client.get(
        "/api/auth/me",
        headers=auth_headers(login),
    ).json()["email"] == "login@example.com"

    rejected = client.post("/api/auth/login", json={
        "email": "login@example.com",
        "password": "incorrect-password",
    })
    assert rejected.status_code == 401
    assert rejected.json()["detail"] == "Email or password is incorrect."


def test_google_resource_discovery_reports_provider_and_saves_resources(client, monkeypatch):
    registration = client.post("/api/auth/register", json={
        "email": "search@example.com",
        "password": "a-strong-password",
    })
    headers = auth_headers(registration)
    subject = client.post("/api/subjects", headers=headers, json={
        "name": "Data Structures",
        "syllabus": "Trees and Graphs\nSorting and Searching",
    }).json()

    calls = []
    resource = {
        "title": "Graph traversal notes",
        "url": "https://www.geeksforgeeks.org/graph-data-structure-and-algorithms/",
        "description": "A concise guide to graph traversal.",
        "domain": "www.geeksforgeeks.org",
    }
    monkeypatch.setattr(api_module, "settings", SimpleNamespace(google_search_configured=True))
    monkeypatch.setattr(api_module, "search_provider", lambda: "Google Programmable Search")
    monkeypatch.setattr(api_module, "search_resources", lambda topic, query: calls.append((topic, query)) or [resource])
    monkeypatch.setattr(api_module, "create_study_guide", lambda topic, resources, syllabus: "Review BFS and DFS.")

    status = client.get("/api/search/status", headers=headers)
    assert status.status_code == 200
    assert status.json() == {
        "provider": "Google Programmable Search",
        "google_api_enabled": True,
        "direct_google_search_available": True,
    }

    discovered = client.post(
        f"/api/subjects/{subject['id']}/resources/discover",
        headers=headers,
        json={"topic": "Trees and Graphs", "query": " graph traversal  lecture "},
    )
    assert discovered.status_code == 200
    assert calls == [("Trees and Graphs", "graph traversal lecture")]
    assert discovered.json()["search_provider"] == "Google Programmable Search"
    assert discovered.json()["resources"][0]["url"] == resource["url"]

    saved = client.get(f"/api/subjects/{subject['id']}/resources", headers=headers)
    assert saved.status_code == 200
    assert len(saved.json()) == 1
    resource_id = saved.json()[0]["id"]
    bookmarked = client.put(
        f"/api/resources/{resource_id}/bookmark",
        headers=headers,
        json={"bookmarked": True},
    )
    assert bookmarked.status_code == 200
    assert bookmarked.json()["bookmarked"] is True
    guides = client.get(f"/api/subjects/{subject['id']}/study-guides", headers=headers)
    assert guides.json() == [{"topic": "Trees and Graphs", "content": "Review BFS and DFS."}]


def test_resource_discovery_accepts_a_user_entered_topic(client, monkeypatch):
    registration = client.post("/api/auth/register", json={
        "email": "custom-topic@example.com",
        "password": "a-strong-password",
    })
    headers = auth_headers(registration)
    subject = client.post("/api/subjects", headers=headers, json={
        "name": "Custom Course",
        "syllabus": "Existing syllabus topic",
    }).json()
    monkeypatch.setattr(api_module, "search_resources", lambda topic, query: [{
        "title": "Open lesson",
        "url": "https://nptel.ac.in/lesson",
        "description": "A free lesson",
        "domain": "nptel.ac.in",
        "topic": topic,
    }])
    monkeypatch.setattr(api_module, "create_study_guide", lambda topic, resources, syllabus: f"Notes for {topic}")

    discovered = client.post(
        f"/api/subjects/{subject['id']}/resources/discover",
        headers=headers,
        json={"topic": "User-entered binary trees", "query": "free video lectures"},
    )

    assert discovered.status_code == 200
    payload = discovered.json()
    assert payload["topic"] == "User-entered binary trees"
    assert payload["resources"][0]["topic"] == "User-entered binary trees"
    assert "User-entered+binary+trees" in payload["google_search_url"]
    assert "site%3Ayoutube.com%2Fplaylist" in payload["youtube_playlist_search_url"]


def test_resource_discovery_succeeds_when_duckduckgo_has_no_results(client, monkeypatch):
    registration = client.post("/api/auth/register", json={
        "email": "empty-search@example.com",
        "password": "a-strong-password",
    })
    headers = auth_headers(registration)
    subject = client.post("/api/subjects", headers=headers, json={
        "name": "Computer Science",
        "syllabus": "Computer networks",
    }).json()
    monkeypatch.setattr(api_module, "search_provider", lambda: "DuckDuckGo fallback")
    monkeypatch.setattr(api_module, "search_resources", lambda topic, query: [])
    monkeypatch.setattr(api_module, "create_study_guide", lambda topic, resources, syllabus: f"Revision notes for {topic}.")

    discovered = client.post(
        f"/api/subjects/{subject['id']}/resources/discover",
        headers=headers,
        json={"topic": "Uncommon computer topic"},
    )

    assert discovered.status_code == 200
    payload = discovered.json()
    assert payload["resources"] == []
    assert payload["search_provider"] == "DuckDuckGo fallback"
    assert payload["fallback_searches"]
    assert payload["study_guide"] == "Revision notes for Uncommon computer topic."
