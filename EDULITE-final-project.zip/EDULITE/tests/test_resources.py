import json
from urllib.parse import parse_qs, urlparse

import pytest

from backend import resource_service
from backend.export_service import export_paper


def test_resource_search_filters_to_exact_allowlisted_domains(monkeypatch):
    class FakeSearch:
        def __init__(self, timeout):
            assert timeout == 12

        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

        def text(self, query, max_results):
            assert "graphs" in query
            assert max_results > 0
            return [
                {"title": "Open course", "href": "https://nptel.ac.in/course", "body": "Course notes"},
                {"title": "Lookalike", "href": "https://nptel.ac.in.attacker.example/course", "body": "Not trusted"},
                {"title": "Insecure", "href": "http://geeksforgeeks.org/graphs", "body": "Not HTTPS"},
                {"title": "Invalid port", "href": "https://geeksforgeeks.org:99999/graphs", "body": "Invalid URL"},
            ]

    import ddgs

    monkeypatch.setattr(ddgs, "DDGS", FakeSearch)
    monkeypatch.setattr(resource_service, "_extract_page_text", lambda url: "Extracted open lecture notes")
    resources = resource_service.search_resources("graphs")
    assert len(resources) == 1
    assert resources[0]["domain"] == "nptel.ac.in"
    assert resources[0]["description"] == "Extracted open lecture notes"


def test_duckduckgo_no_results_returns_empty_list(monkeypatch):
    import ddgs
    from ddgs.exceptions import DDGSException

    class EmptySearch:
        def __init__(self, timeout):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

        def text(self, query, max_results):
            raise DDGSException("No results found.")

    monkeypatch.setattr(ddgs, "DDGS", EmptySearch)

    assert resource_service.search_resources("a topic with no indexed results") == []


def test_duckduckgo_provider_errors_are_still_reported(monkeypatch):
    import ddgs
    from ddgs.exceptions import DDGSException

    class FailedSearch:
        def __init__(self, timeout):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

        def text(self, query, max_results):
            raise DDGSException("All search backends failed.")

    monkeypatch.setattr(ddgs, "DDGS", FailedSearch)

    with pytest.raises(RuntimeError, match="All search backends failed"):
        resource_service.search_resources("graphs")


def test_study_notes_export_includes_guide_content():
    paper = {
        "title": "Revision notes",
        "questions": [],
        "study_guides": [{"topic": "Graph traversal", "content": "## Key ideas\n\nBreadth-first search uses a queue."}],
    }
    pdf, content_type, _ = export_paper(paper, "pdf")
    assert content_type == "application/pdf"
    assert pdf.startswith(b"%PDF")
    docx, content_type, _ = export_paper(paper, "docx")
    assert content_type.startswith("application/vnd.openxmlformats")
    assert docx.startswith(b"PK")


def test_google_programmable_search_uses_trusted_domains_and_filters_results(monkeypatch):
    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

        def read(self):
            return json.dumps({"items": [
                {"title": "Lecture notes", "link": "https://nptel.ac.in/course/1", "snippet": "Open lectures"},
                {"title": "Untrusted", "link": "https://example.com/notes", "snippet": "Not allowed"},
            ]}).encode()

    def fake_urlopen(request, timeout):
        assert timeout == 12
        query = parse_qs(urlparse(request.full_url).query)
        assert query["key"] == ["test-google-key"]
        assert query["cx"] == ["test-engine"]
        assert "site:nptel.ac.in" in query["q"][0]
        assert "site:geeksforgeeks.org" in query["q"][0]
        assert "database transactions" in query["q"][0]
        return FakeResponse()

    monkeypatch.setattr(resource_service.settings, "google_search_api_key", "test-google-key")
    monkeypatch.setattr(resource_service.settings, "google_search_engine_id", "test-engine")
    monkeypatch.setattr(resource_service.urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(resource_service, "_extract_page_text", lambda url: "Verified lecture content")

    assert resource_service.search_provider() == "Google Programmable Search"
    results = resource_service.search_resources("DBMS", "database transactions")
    assert len(results) == 1
    assert results[0]["domain"] == "nptel.ac.in"
    assert results[0]["description"] == "Verified lecture content"


def test_google_search_requires_both_credentials(monkeypatch):
    monkeypatch.setattr(resource_service.settings, "google_search_api_key", "test-key")
    monkeypatch.setattr(resource_service.settings, "google_search_engine_id", "")
    assert "needs both" in resource_service.search_provider()
    with pytest.raises(RuntimeError, match="GOOGLE_SEARCH_API_KEY"):
        resource_service.search_resources("Graphs")


def test_google_search_url_rejects_non_allowlisted_domains():
    with pytest.raises(ValueError, match="allowlisted"):
        resource_service.trusted_search_url("Graphs", "example.com")


def test_gemini_study_guide_parses_markdown_response(monkeypatch):
    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

        def read(self):
            return json.dumps({
                "candidates": [{
                    "content": {
                        "parts": [{
                            "text": "```markdown\n# Graph traversal\n\n" + ("Review breadth-first and depth-first search. " * 4) + "\n```"
                        }]
                    }
                }]
            }).encode()

    monkeypatch.setattr(resource_service.settings, "gemini_api_key", "test-gemini-key")
    monkeypatch.setattr(resource_service.urllib.request, "urlopen", lambda request, timeout: FakeResponse())

    guide = resource_service.create_study_guide("Graphs", [], "Graph traversal")
    assert guide.startswith("# Graph traversal")
    assert "```" not in guide


def test_youtube_playlist_search_url_is_a_google_web_search():
    url = resource_service.youtube_playlist_search_url("Binary trees", "lectures")
    query = parse_qs(urlparse(url).query)["q"][0]
    assert urlparse(url).netloc == "www.google.com"
    assert "Binary trees lectures" in query
    assert "site:youtube.com/playlist" in query
    assert "free full course playlist" in query
