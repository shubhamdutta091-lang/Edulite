from backend.models import Question, Subject
from ml_pipeline.classification import classify_question, duplicate_groups, similar_question_score
from ml_pipeline.generation import generate_questions
from ml_pipeline.ingestion import extract_text, split_questions
from ml_pipeline.prediction import analyze_patterns, predict_topics


def test_splits_questions_and_detects_year_and_marks():
    questions, year = split_questions(
        "Q1. Explain linked lists. [5 marks]\n\nQ2. Compare two traversal algorithms. (10 marks)",
        "paper-2024.txt",
    )
    assert year == 2024
    assert len(questions) == 2
    assert [item["marks"] for item in questions] == [5.0, 10.0]
    assert questions[0]["text"].startswith("Q1.")


def test_splits_lettered_subquestions_and_long_question_labels():
    questions, _ = split_questions(
        "Question 1(a) Explain the first case.\n1(b) Compare the second case.\n(i) State one limitation.",
        "paper.txt",
    )
    assert len(questions) == 3
    assert "first case" in questions[0]["text"]
    assert "second case" in questions[1]["text"]


def test_extracts_text_from_digital_pdf():
    import pymupdf

    document = pymupdf.open()
    page = document.new_page()
    page.insert_text((72, 72), "Q1. Explain tree traversal and give an example. [5 marks]")
    text = extract_text("paper.pdf", document.tobytes())
    assert "tree traversal" in text
    questions, _ = split_questions(text, "paper-2024.pdf")
    assert len(questions) == 1
    assert questions[0]["marks"] == 5


def test_extracts_paragraphs_and_tables_from_docx():
    from docx import Document
    from io import BytesIO

    document = Document()
    document.add_paragraph("Q1. Explain binary search trees. [5 marks]")
    table = document.add_table(rows=1, cols=1)
    table.cell(0, 0).text = "Q2. Compare tree traversal algorithms. [10 marks]"
    document.add_paragraph("Q3. Describe a balanced tree. [8 marks]")
    buffer = BytesIO()
    document.save(buffer)

    text = extract_text("paper-2024.docx", buffer.getvalue())
    questions, year = split_questions(text, "paper-2024.docx")
    assert year == 2024
    assert len(questions) == 3
    assert questions[0]["marks"] == 5
    assert questions[1]["marks"] == 10
    assert questions[2]["marks"] == 8


def test_extracts_utf8_markdown_and_lists_supported_input_formats():
    from ml_pipeline.ingestion import SUPPORTED_FORMATS_LABEL, SUPPORTED_TYPES

    text = extract_text("questions.md", "# Paper\n\nQ1. Describe a graph. [5 marks]".encode())
    questions, _ = split_questions(text, "questions.md")
    assert len(questions) == 1
    assert {".pdf", ".docx", ".txt", ".md", ".webp", ".tiff"} <= SUPPORTED_TYPES
    assert "DOCX" in SUPPORTED_FORMATS_LABEL


def test_rejects_malformed_word_documents_with_clear_error():
    import pytest

    with pytest.raises(ValueError, match="damaged or is not a valid .docx"):
        extract_text("paper.docx", b"not a Word document")


def test_ocr_supports_webp_exam_images(monkeypatch):
    from io import BytesIO
    from PIL import Image
    import pytesseract
    import ml_pipeline.ingestion as ingestion

    image = Image.new("RGB", (40, 40), "white")
    buffer = BytesIO()
    image.save(buffer, format="WEBP")
    monkeypatch.setattr(ingestion, "_configure_tesseract", lambda module: None)
    monkeypatch.setattr(pytesseract, "image_to_string", lambda image, config: "Q1. Describe a graph. [5 marks]")

    text = extract_text("paper.webp", buffer.getvalue())
    questions, _ = split_questions(text, "paper.webp")
    assert len(questions) == 1
    assert questions[0]["marks"] == 5


def test_ocr_reads_each_page_of_a_multipage_tiff(monkeypatch):
    from io import BytesIO
    from PIL import Image
    import ml_pipeline.ingestion as ingestion
    import pytesseract

    first = Image.new("RGB", (40, 40), "white")
    second = Image.new("RGB", (40, 40), "black")
    buffer = BytesIO()
    first.save(buffer, format="TIFF", save_all=True, append_images=[second])
    calls = []

    monkeypatch.setattr(ingestion, "_configure_tesseract", lambda module: None)
    monkeypatch.setattr(pytesseract, "image_to_string", lambda image, config: calls.append(config) or f"Q{len(calls)}. Example question text.")

    text = extract_text("scan.tiff", buffer.getvalue())
    assert len(calls) == 2
    assert text.count("Example question text") == 2


def test_missing_tesseract_engine_produces_install_instructions(monkeypatch):
    import ml_pipeline.ingestion as ingestion
    import pytesseract
    import pytest

    monkeypatch.delenv("TESSERACT_CMD", raising=False)
    monkeypatch.setattr(ingestion.settings, "tesseract_cmd", "")
    monkeypatch.setattr(ingestion.shutil, "which", lambda command: None)
    monkeypatch.setattr(ingestion.os.path, "isfile", lambda path: False)
    monkeypatch.setattr(ingestion.Path, "is_file", lambda path: False)

    with pytest.raises(RuntimeError, match="Tesseract OCR engine is not installed") as error:
        ingestion._configure_tesseract(pytesseract)
    assert "winget install" in str(error.value)
    assert "TESSERACT_CMD" in str(error.value)


def test_image_ocr_falls_back_to_builtin_engine_without_tesseract(monkeypatch):
    from io import BytesIO
    from PIL import Image
    import ml_pipeline.ingestion as ingestion

    image = Image.new("RGB", (40, 40), "white")
    buffer = BytesIO()
    image.save(buffer, format="PNG")

    def missing_tesseract(_):
        raise RuntimeError("Tesseract is not installed")

    monkeypatch.setattr(ingestion, "_configure_tesseract", missing_tesseract)
    monkeypatch.setattr(ingestion, "_rapidocr_image_to_string", lambda image: "Q1. Explain binary tree traversal. [5 marks]")

    text = ingestion.extract_text("scan.png", buffer.getvalue())
    questions, _ = ingestion.split_questions(text, "scan.png")
    assert len(questions) == 1
    assert questions[0]["marks"] == 5


def test_image_ocr_reports_both_engines_when_fallback_fails(monkeypatch):
    from io import BytesIO
    from PIL import Image
    import ml_pipeline.ingestion as ingestion
    import pytest

    image = Image.new("RGB", (40, 40), "white")
    buffer = BytesIO()
    image.save(buffer, format="PNG")

    monkeypatch.setattr(ingestion, "_configure_tesseract", lambda module: (_ for _ in ()).throw(RuntimeError("Tesseract unavailable")))
    monkeypatch.setattr(ingestion, "_rapidocr_image_to_string", lambda image: (_ for _ in ()).throw(RuntimeError("model unavailable")))

    with pytest.raises(RuntimeError, match="built-in RapidOCR fallback also failed"):
        ingestion.extract_text("scan.png", buffer.getvalue())


def test_image_ocr_reports_when_scan_contains_no_recognizable_text(monkeypatch):
    from io import BytesIO
    from PIL import Image
    import ml_pipeline.ingestion as ingestion
    import pytesseract
    import pytest

    image = Image.new("RGB", (40, 40), "white")
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    monkeypatch.setattr(ingestion, "_configure_tesseract", lambda module: None)
    monkeypatch.setattr(pytesseract, "image_to_string", lambda image, config: "  \n ")

    with pytest.raises(ValueError, match="No readable text was found in this scan"):
        extract_text("scan.png", buffer.getvalue())


def test_classifies_topic_and_question_type():
    subject = Subject(name="Data Structures", syllabus="Trees and Graphs\nSorting and Searching")
    result = classify_question("Compare breadth-first search and depth-first search on a graph.", subject)
    assert result["topic"] == "Trees and Graphs"
    assert result["question_type"] == "Short Answer"


def test_cosine_similarity_and_duplicate_grouping():
    first = Question(id=1, text="Explain binary search trees and balancing.", topic="Trees")
    second = Question(id=2, text="Explain balancing in binary search trees.", topic="Trees")
    third = Question(id=3, text="Write a SQL query using an index.", topic="DBMS")
    assert similar_question_score(first.text, second.text) > similar_question_score(first.text, third.text)
    assert duplicate_groups([first, second, third], threshold=0.4) == [[1, 2]]


def test_patterns_and_probability_are_bounded():
    subject = Subject(name="Data Structures", syllabus="Trees and Graphs\nSorting and Searching")
    questions = [
        Question(id=index + 1, text=f"Tree question {index}", year=2020 + index, topic="Trees and Graphs", marks=5)
        for index in range(3)
    ]
    patterns = analyze_patterns(questions, ["Trees and Graphs", "Sorting and Searching"])
    assert patterns["years"] == [2020, 2021, 2022]
    assert patterns["topic_stats"][0]["appearances"] == 3
    predictions = predict_topics(questions, ["Trees and Graphs", "Sorting and Searching"])
    assert predictions
    assert all(0.05 <= item["probability"] <= 0.95 for item in predictions)
    assert all(item["probability_percent"] <= 95 for item in predictions)


def test_missing_exam_years_produce_neutral_estimates():
    question = Question(id=1, text="Tree example", year=None, topic="Trees and Graphs", marks=5)
    predictions = predict_topics([question], ["Trees and Graphs", "Sorting and Searching"])
    assert all(item["observed_papers"] == 0 for item in predictions)
    assert all(item["probability"] == 0.5 for item in predictions)
    assert all("No historical appearances" in item["reasoning"] for item in predictions)


def test_ensemble_trains_when_historical_data_is_sufficient():
    topics = ["Trees", "Sorting", "Graphs", "Hashing"]
    questions = []
    question_id = 1
    for year_index in range(10):
        for topic_index, topic in enumerate(topics):
            if (year_index + topic_index) % (2 + topic_index % 2) != 0:
                questions.append(Question(
                    id=question_id,
                    text=f"Exam question about {topic} in {2014 + year_index}.",
                    year=2014 + year_index,
                    topic=topic,
                    marks=float(4 + topic_index),
                ))
                question_id += 1
    predictions = predict_topics(questions, topics)
    assert len(predictions) == len(topics)
    assert all(0.05 <= item["probability"] <= 0.95 for item in predictions)
    evaluation = predictions[0]["rolling_origin_evaluation"]
    assert evaluation["folds"] >= 1
    assert 0 <= evaluation["accuracy"] <= 1
    assert 0 <= evaluation["brier_score"] <= 1


def test_offline_generation_returns_original_validated_questions():
    subject = Subject(name="Data Structures", syllabus="Trees and Graphs")
    generated = generate_questions(subject, [], ["Trees and Graphs"], 1, 5, "MCQ", "Medium")
    assert len(generated) == 1
    assert generated[0]["options"]
    assert generated[0]["correct_option"] in {"A", "B", "C", "D"}
    assert generated[0]["validation"]["duplicate_check"] == "passed"


def test_offline_generation_supports_twenty_unique_practice_questions():
    subject = Subject(name="Data Structures", syllabus="Trees and Graphs")
    generated = generate_questions(subject, [], ["Trees and Graphs"], 20, 5, "MCQ", "Medium")
    assert len(generated) == 20
    assert len({item["question"] for item in generated}) == 20


def test_gemini_question_generation_parses_fenced_json_response(monkeypatch):
    import json
    import ml_pipeline.generation as generation

    class FakeResponse:
        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

        def read(self):
            return json.dumps({
                "candidates": [{
                    "content": {
                        "parts": [{"text": '```json\n{"question":"Explain graph traversal clearly.","answer":"A complete answer describes BFS and DFS."}\n```'}]
                    }
                }]
            }).encode()

    monkeypatch.setattr(generation.settings, "gemini_api_key", "test-gemini-key")
    monkeypatch.setattr(generation.urllib.request, "urlopen", lambda request, timeout: FakeResponse())

    assert generation._call_gemini("test prompt") == {
        "question": "Explain graph traversal clearly.",
        "answer": "A complete answer describes BFS and DFS.",
    }


def test_vector_store_falls_back_to_tfidf_when_semantic_model_is_unavailable(monkeypatch):
    import ml_pipeline.vector_store as vector_store

    def raise_model_error():
        raise OSError("offline model unavailable")

    monkeypatch.setattr(vector_store, "_sentence_model", raise_model_error)
    store = vector_store.QuestionVectorStore(["Explain binary trees", "Explain sorting algorithms"])

    assert store.model is None
    assert store.vectorizer is not None
    assert store.matrix is not None
    matches = store.search("binary tree", limit=2)
    assert matches and matches[0][0] == 0
    assert matches[0][1] > 0
