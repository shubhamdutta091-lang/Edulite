export type Tab = "home" | "subjects" | "practice" | "resources";

export interface User {
  id: number;
  email: string;
}

export interface Subject {
  id: number;
  name: string;
  syllabus: string;
  is_public: boolean;
}

export interface Prediction {
  topic: string;
  probability: number;
  probability_percent: number;
  reasoning: string;
  appearances: number;
  gap: number;
}

export interface Analytics {
  years: number[];
  topic_matrix: Array<Record<string, string | boolean>>;
  topic_stats: Array<{
    topic: string;
    appearances: number;
    frequency: number;
    gap: number;
    average_marks: number | null;
  }>;
  question_type_mix: Record<string, number>;
  marks_distribution: Record<string, number>;
  difficulty_trend: Record<string, Record<string, number>>;
  total_questions: number;
}

export interface Question {
  id?: number;
  preview_id?: number;
  text: string;
  year: number | null;
  topic: string;
  marks: number | null;
  difficulty: string;
  question_type: string;
  confidence?: number;
  needs_review?: boolean;
  source: string;
  included?: boolean;
}

export interface Resource {
  id: number;
  topic: string;
  title: string;
  url: string;
  description: string;
  domain: string;
  bookmarked: boolean;
}

export interface PracticeQuestion {
  question_number: number;
  question: string;
  answer: string;
  topic: string;
  marks: number;
  difficulty: string;
  question_type: string;
  options?: string[];
  correct_option?: string;
}

export interface PracticePaper {
  id: number;
  title: string;
  questions: PracticeQuestion[];
  notice?: string;
}
