"use client";

import {
  ArrowDownToLine,
  ArrowRight,
  Bookmark,
  Check,
  ChevronDown,
  ExternalLink,
  FileImage,
  FileText,
  LoaderCircle,
  Plus,
  Search,
  Sparkles,
  Upload,
  X,
} from "lucide-react";
import {
  type ChangeEvent,
  type DragEvent,
  type FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  AppShell,
  BentoGrid,
  HeroBanner,
  ProbabilityChart,
  SectionTitle,
  StudyTimerCard,
  TopicHeatmap,
} from "./components";
import type {
  Analytics,
  PracticePaper,
  Prediction,
  Question,
  Resource,
  Subject,
  Tab,
  User,
} from "./types";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";
const FILE_ACCEPT = ".pdf,.docx,.txt,.md,.markdown,.png,.jpg,.jpeg,.webp,.bmp,.tif,.tiff";
const FORMAT_LABEL = "PDF, DOCX, TXT, Markdown, PNG, JPG, WEBP, BMP, TIFF";

function youtubeNumericalSearchUrl(topic: string) {
  const search = new URL("https://www.youtube.com/results");
  search.searchParams.set("search_query", `${topic} computer science numerical problems solved examples`);
  return search.toString();
}

interface ApiOptions extends RequestInit {
  json?: unknown;
}

async function api<T>(path: string, token: string | null, options: ApiOptions = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (options.json !== undefined) headers.set("Content-Type", "application/json");
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers,
      body: options.json !== undefined ? JSON.stringify(options.json) : options.body,
    });
  } catch (error) {
    if (error instanceof TypeError) {
      throw new Error(`Could not connect to EduLite's API at ${API_BASE}. Start the backend server and try again.`);
    }
    throw error;
  }
  const contentType = response.headers.get("content-type") ?? "";
  const result = contentType.includes("application/json") ? await response.json() as unknown : await response.blob();
  if (!response.ok) {
    const detail = result && typeof result === "object" && "detail" in result ? result.detail : "";
    throw new Error(Array.isArray(detail) ? detail.map((item) => item.msg).join(", ") : String(detail || `Request failed (${response.status})`));
  }
  return result as T;
}

interface WorkspaceData {
  analytics: Analytics;
  predictions: Prediction[];
  questions: Question[];
  papers: Array<{ id: number; title: string; created_at: string }>;
  resources: Resource[];
  guides: Array<{ topic: string; content: string }>;
  recommendations: Array<{ topic: string; needs_practice: number; suggestion: string }>;
}

interface StudyTimerState {
  totalSeconds: number;
  sessionSeconds: number;
  startedAt: number | null;
}

const EMPTY_STUDY_TIMER: StudyTimerState = {
  totalSeconds: 0,
  sessionSeconds: 0,
  startedAt: null,
};

function elapsedStudySeconds(timer: StudyTimerState, now: number) {
  return timer.startedAt === null ? 0 : Math.max(0, Math.floor((now - timer.startedAt) / 1000));
}

const emptyAnalytics: Analytics = {
  years: [],
  topic_matrix: [],
  topic_stats: [],
  question_type_mix: {},
  marks_distribution: {},
  difficulty_trend: {},
  total_questions: 0,
};

function todayLabel() {
  return new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric" }).format(new Date());
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export default function Home() {
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [subjectId, setSubjectId] = useState<number | null>(null);
  const [tab, setTab] = useState<Tab>("home");
  const [externalTutorTopic, setExternalTutorTopic] = useState("");
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [checkingSession, setCheckingSession] = useState(true);
  const [authBusy, setAuthBusy] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [search, setSearch] = useState("");
  const [data, setData] = useState<WorkspaceData>({
    analytics: emptyAnalytics,
    predictions: [],
    questions: [],
    papers: [],
    resources: [],
    guides: [],
    recommendations: [],
  });
  const [preview, setPreview] = useState<Question[]>([]);
  const [uploadStatus, setUploadStatus] = useState("");
  const [uploadIsError, setUploadIsError] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState("");
  const [practiceQuestionType, setPracticeQuestionType] = useState("Any");
  const [practiceCustomTopic, setPracticeCustomTopic] = useState("");
  const [practiceSelectedTopics, setPracticeSelectedTopics] = useState<string[]>([]);
  const [resourceTopic, setResourceTopic] = useState("");
  const [searchTerms, setSearchTerms] = useState("");
  const [resourceSearchLinks, setResourceSearchLinks] = useState<{ topic: string; google: string; youtube: string } | null>(null);
  const [guide, setGuide] = useState("");
  const [paper, setPaper] = useState<PracticePaper | null>(null);
  const [attempted, setAttempted] = useState<Record<number, string>>({});
  const [subjectDialog, setSubjectDialog] = useState(false);
  const [studyTimer, setStudyTimer] = useState<StudyTimerState>(EMPTY_STUDY_TIMER);
  const [studyTimerNow, setStudyTimerNow] = useState(() => Date.now());
  const [studyTimerOwner, setStudyTimerOwner] = useState<number | null>(null);

  const subject = subjects.find((item) => item.id === subjectId) ?? null;
  const topics = useMemo(() => {
    const syllabusTopics = (subject?.syllabus ?? "").split(/\r?\n/).map((line) => line.replace(/^[\s#\-0-9.)]+/, "").trim()).filter(Boolean);
    return [...new Set([...syllabusTopics, ...data.analytics.topic_stats.map((item) => item.topic)])];
  }, [data.analytics.topic_stats, subject?.syllabus]);
  useEffect(() => {
    setPracticeSelectedTopics((current) => {
      const available = current.filter((topicName) => topics.includes(topicName));
      return available.length ? available : topics.slice(0, 2);
    });
  }, [topics]);
  const activeTopic = topics.includes(selectedTopic) ? selectedTopic : topics[0] ?? "";
  const fileInputId = "pyq-files";

  const refreshWorkspace = useCallback(async (accessToken: string) => {
    const [currentUser, currentSubjects] = await Promise.all([
      api<User>("/api/auth/me", accessToken),
      api<Subject[]>("/api/subjects", accessToken),
    ]);
    setUser(currentUser);
    setSubjects(currentSubjects);
    setSubjectId((current) => currentSubjects.some((item) => item.id === current) ? current : currentSubjects[0]?.id ?? null);
  }, []);

  useEffect(() => {
    const savedToken = localStorage.getItem("edulite-token");
    if (!savedToken) {
      setCheckingSession(false);
      return;
    }
    setToken(savedToken);
    void refreshWorkspace(savedToken)
      .catch(() => {
        localStorage.removeItem("edulite-token");
        setToken(null);
      })
      .finally(() => setCheckingSession(false));
  }, [refreshWorkspace]);

  useEffect(() => {
    if (!user) {
      setStudyTimer(EMPTY_STUDY_TIMER);
      setStudyTimerOwner(null);
      return;
    }

    const storageKey = `edulite-study-timer-${user.id}`;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved) as Partial<StudyTimerState>;
        setStudyTimer({
          totalSeconds: Number.isFinite(parsed.totalSeconds) ? Math.max(0, Math.floor(parsed.totalSeconds!)) : 0,
          sessionSeconds: Number.isFinite(parsed.sessionSeconds) ? Math.max(0, Math.floor(parsed.sessionSeconds!)) : 0,
          startedAt: Number.isFinite(parsed.startedAt) ? parsed.startedAt! : null,
        });
      } else {
        setStudyTimer(EMPTY_STUDY_TIMER);
      }
    } catch {
      localStorage.removeItem(storageKey);
      setStudyTimer(EMPTY_STUDY_TIMER);
    }
    setStudyTimerOwner(user.id);
    setStudyTimerNow(Date.now());
  }, [user]);

  useEffect(() => {
    if (!user || studyTimerOwner !== user.id) return;
    localStorage.setItem(`edulite-study-timer-${user.id}`, JSON.stringify(studyTimer));
  }, [studyTimer, studyTimerOwner, user]);

  useEffect(() => {
    if (studyTimer.startedAt === null) return;
    const interval = window.setInterval(() => setStudyTimerNow(Date.now()), 1000);
    return () => window.clearInterval(interval);
  }, [studyTimer.startedAt]);

  const loadData = useCallback(async () => {
    if (!token || !subjectId) {
      setData((current) => ({ ...current, analytics: emptyAnalytics }));
      return;
    }
    setBusy(true);
    try {
      const base = `/api/subjects/${subjectId}`;
      const [analytics, predictionResponse, questionResponse, papers, resources, guides, recommendations] = await Promise.all([
        api<Analytics>(`${base}/analytics`, token),
        api<{ predictions: Prediction[] }>(`${base}/predictions`, token),
        api<{ questions: Question[] }>(`${base}/questions`, token),
        api<WorkspaceData["papers"]>("/api/papers", token),
        api<Resource[]>(`${base}/resources`, token),
        api<WorkspaceData["guides"]>(`${base}/study-guides`, token),
        api<{ recommendations: WorkspaceData["recommendations"] }>(`${base}/recommendations`, token),
      ]);
      setData({ analytics, predictions: predictionResponse.predictions, questions: questionResponse.questions, papers, resources, guides, recommendations: recommendations.recommendations });
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not load your workspace.");
    } finally {
      setBusy(false);
    }
  }, [subjectId, token]);

  useEffect(() => {
    if (token && subjectId) void loadData();
  }, [loadData, subjectId, token]);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(""), 3800);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  useEffect(() => {
    setResourceTopic(activeTopic);
    setResourceSearchLinks(null);
  }, [activeTopic]);

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAuthBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      const result = await api<{ access_token: string }>(`/api/auth/${authMode === "register" ? "register" : "login"}`, null, {
        method: "POST",
        json: { email: form.get("email"), password: form.get("password") },
      });
      localStorage.setItem("edulite-token", result.access_token);
      setToken(result.access_token);
      await refreshWorkspace(result.access_token);
      setToast(authMode === "register" ? "Welcome to your new study space." : "Welcome back.");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Sign-in failed.");
    } finally {
      setAuthBusy(false);
    }
  }

  function signOut() {
    if (user && studyTimer.startedAt !== null) {
      const elapsed = elapsedStudySeconds(studyTimer, Date.now());
      const pausedTimer = {
        totalSeconds: studyTimer.totalSeconds + elapsed,
        sessionSeconds: studyTimer.sessionSeconds + elapsed,
        startedAt: null,
      };
      localStorage.setItem(`edulite-study-timer-${user.id}`, JSON.stringify(pausedTimer));
      setStudyTimer(pausedTimer);
    }
    localStorage.removeItem("edulite-token");
    setToken(null);
    setUser(null);
    setSubjects([]);
    setSubjectId(null);
    setPreview([]);
    setError("");
    setAuthMode("login");
    setTab("home");
  }

  function toggleStudyTimer() {
    const now = Date.now();
    setStudyTimer((current) => {
      if (current.startedAt !== null) {
        const elapsed = elapsedStudySeconds(current, now);
        return {
          totalSeconds: current.totalSeconds + elapsed,
          sessionSeconds: current.sessionSeconds + elapsed,
          startedAt: null,
        };
      }
      return { ...current, startedAt: now };
    });
    setStudyTimerNow(now);
  }

  function resetStudySession() {
    const now = Date.now();
    setStudyTimer((current) => {
      const elapsed = elapsedStudySeconds(current, now);
      return {
        totalSeconds: current.totalSeconds + elapsed,
        sessionSeconds: 0,
        startedAt: null,
      };
    });
    setStudyTimerNow(now);
  }

  function externalTutorSearch() {
    const topic = externalTutorTopic.trim();
    if (!topic) return null;
    return {
      google: `https://www.google.com/search?q=${encodeURIComponent(`${topic} free course tutorial`)}`,
      youtube: `https://www.youtube.com/results?search_query=${encodeURIComponent(`${topic} free full course playlist`)}`,
    };
  }

  function renderExternalTutorSearch() {
    const links = externalTutorSearch();
    return (
      <div className="external-tutor-search">
        <label>Subject or topic not listed? Search the wider web.
          <input value={externalTutorTopic} maxLength={160} onChange={(event) => setExternalTutorTopic(event.target.value)} placeholder="e.g. Quantum computing" aria-label="Search any subject or topic" />
        </label>
        <div className="external-tutor-links">
          <a className={`button button-soft ${links ? "" : "is-disabled"}`} href={links?.google ?? "#"} target="_blank" rel="noopener noreferrer" aria-disabled={!links} onClick={(event) => { if (!links) event.preventDefault(); }}><ExternalLink size={14} /> Search Google</a>
          <a className={`button button-soft ${links ? "" : "is-disabled"}`} href={links?.youtube ?? "#"} target="_blank" rel="noopener noreferrer" aria-disabled={!links} onClick={(event) => { if (!links) event.preventDefault(); }}><ExternalLink size={14} /> Find YouTube lessons</a>
        </div>
      </div>
    );
  }

  async function createSubject(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!token) return;
    const form = new FormData(event.currentTarget);
    try {
      const created = await api<Subject>("/api/subjects", token, {
        method: "POST",
        json: { name: form.get("name"), syllabus: form.get("syllabus") },
      });
      setSubjects((current) => [...current, created]);
      setSubjectId(created.id);
      setSubjectDialog(false);
      setToast(`${created.name} added to your workspace.`);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not create subject.");
    }
  }

  async function uploadFiles(files: FileList | File[]) {
    if (!token || !subjectId || !files.length) return;
    const form = new FormData();
    Array.from(files).forEach((file) => form.append("files", file));
    setUploadStatus(`Uploading ${files.length} file${files.length === 1 ? "" : "s"} and reading its contents…`);
    setUploadIsError(false);
    setBusy(true);
    try {
      const response = await api<{ questions: Question[]; message: string }>(`/api/subjects/${subjectId}/upload`, token, { method: "POST", body: form });
      setPreview(response.questions.map((question) => ({ ...question, included: true })));
      setUploadStatus(response.message);
      setTab("subjects");
      setToast("Extraction finished. Review the questions, then save them to your library.");
    } catch (requestError) {
      const message = requestError instanceof Error ? requestError.message : "File upload failed.";
      setUploadStatus(message);
      setUploadIsError(true);
    } finally {
      setBusy(false);
    }
  }

  function handleDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setDragging(false);
    void uploadFiles(event.dataTransfer.files);
  }

  function updatePreview(index: number, patch: Partial<Question>) {
    setPreview((current) => current.map((item, position) => position === index ? { ...item, ...patch } : item));
  }

  async function savePreview(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!token || !subjectId) return;
    const selected = preview.filter((item) => item.included !== false);
    if (!selected.length) {
      setUploadIsError(true);
      setUploadStatus("Select at least one extracted question to save.");
      return;
    }
    setBusy(true);
    setUploadStatus("Saving reviewed questions to your private library…");
    setUploadIsError(false);
    try {
      const result = await api<{ message: string }>(`/api/subjects/${subjectId}/questions/import`, token, {
        method: "POST",
        json: {
          questions: selected.map(({ text, year, topic, marks, difficulty, question_type, source }) => ({ text, year, topic, marks, difficulty, question_type, source })),
        },
      });
      setPreview([]);
      setUploadStatus(result.message);
      setToast(result.message);
      await loadData();
    } catch (requestError) {
      const message = requestError instanceof Error ? requestError.message : "Could not save the extracted questions.";
      setUploadStatus(message);
      setUploadIsError(true);
    } finally {
      setBusy(false);
    }
  }

  async function discoverResources() {
    const topic = resourceTopic.trim();
    if (!token || !subjectId || !topic) return;
    const query = searchTerms.trim();
    setResourceSearchLinks({
      topic,
      google: `https://www.google.com/search?q=${encodeURIComponent(`${topic} ${query} free study resources`)}`,
      youtube: `https://www.google.com/search?q=${encodeURIComponent(`${topic} ${query} free full course playlist site:youtube.com/playlist`)}`,
    });
    setBusy(true);
    setError("");
    try {
      const result = await api<{
        topic: string;
        resources: Resource[];
        study_guide: string;
        search_provider: string;
        google_search_url: string;
        youtube_playlist_search_url: string;
      }>(`/api/subjects/${subjectId}/resources/discover`, token, {
        method: "POST",
        json: { topic, query: searchTerms },
      });
      setGuide(result.study_guide);
      setResourceTopic(result.topic);
      setResourceSearchLinks({ topic: result.topic, google: result.google_search_url, youtube: result.youtube_playlist_search_url });
      setToast(`Study resources refreshed using ${result.search_provider}.`);
      await loadData();
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not discover study resources.");
    } finally {
      setBusy(false);
    }
  }

  async function toggleBookmark(resource: Resource) {
    if (!token) return;
    try {
      await api(`/api/resources/${resource.id}/bookmark`, token, {
        method: "PUT",
        json: { bookmarked: !resource.bookmarked },
      });
      await loadData();
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not update bookmark.");
    }
  }

  async function generatePaper(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!token || !subjectId) return;
    const form = new FormData(event.currentTarget);
    const customTopic = practiceCustomTopic.trim();
    if (!practiceSelectedTopics.length && !customTopic) {
      setError("Choose a syllabus topic or enter a custom computer topic.");
      return;
    }
    if (practiceSelectedTopics.length + (customTopic ? 1 : 0) > 10) {
      setError("Choose no more than 10 topics at a time.");
      return;
    }
    setBusy(true);
    setError("");
    setAttempted({});
    try {
      const generated = await api<PracticePaper>(`/api/subjects/${subjectId}/papers`, token, {
        method: "POST",
        json: {
          topics: practiceSelectedTopics,
          custom_topic: customTopic,
          question_count: Number(form.get("count")),
          marks_per_question: Number(form.get("marks")),
          question_type: form.get("type"),
          difficulty: form.get("difficulty"),
        },
      });
      setPaper(generated);
      setToast("Your practice set is ready.");
      await loadData();
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not generate the practice paper.");
    } finally {
      setBusy(false);
    }
  }

  async function submitAttempt(questionNumber: number, questionType: string) {
    if (!token || !paper) return;
    const answer = attempted[questionNumber]?.trim();
    if (!answer) {
      setError("Choose or write an answer before checking it.");
      return;
    }
    try {
      const response = await api<{ is_correct: boolean | null; model_answer?: string }>(`/api/papers/${paper.id}/attempt`, token, {
        method: "POST",
        json: { question_id: questionNumber, answer, self_evaluation: questionType === "MCQ" ? null : 3 },
      });
      if (response.is_correct === null && response.model_answer) {
        setToast(`Response saved. Model answer: ${response.model_answer}`);
      } else {
        setToast(response.is_correct ? "Correct — nice work!" : "Response saved. Review the model answer below.");
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not save your practice answer.");
    }
  }

  async function exportPaper(format: "pdf" | "docx") {
    if (!token || !paper) return;
    try {
      const file = await api<Blob>(`/api/papers/${paper.id}/export?format=${format}`, token);
      download(file, `edulite-practice.${format}`);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not export the practice paper.");
    }
  }

  async function exportNotes(format: "pdf" | "docx") {
    if (!token || !subjectId) return;
    try {
      const file = await api<Blob>(`/api/subjects/${subjectId}/study-guides/export?format=${format}`, token);
      download(file, `edulite-study-notes.${format}`);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not export revision notes.");
    }
  }

  async function updateQuestion(question: Question) {
    if (!token || !question.id) return;
    try {
      await api(`/api/questions/${question.id}`, token, {
        method: "PUT",
        json: {
          text: question.text,
          topic: question.topic,
          year: question.year,
          marks: question.marks,
          difficulty: question.difficulty,
          question_type: question.question_type,
        },
      });
      setToast("Question review saved.");
      await loadData();
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not save this question.");
    }
  }

  function searchSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const query = search.trim().toLocaleLowerCase();
    const matchingSubject = subjects.find((item) => item.name.toLocaleLowerCase().includes(query));
    if (matchingSubject) setSubjectId(matchingSubject.id);
    setTab("subjects");
  }

  if (checkingSession) {
    return <div className="loading-screen"><span className="brand-mark"><Sparkles size={18} /></span><span>Opening your study space…</span></div>;
  }

  if (!token || !user) {
    return (
      <main className="auth-page">
        <section className="auth-story">
          <a className="brand brand-light" href="#"><span className="brand-mark"><Sparkles size={17} /></span><span>edu<span>lite</span></span></a>
          <div className="auth-story-copy"><span className="eyebrow"><Sparkles size={14} /> YOUR EXAM COMPANION</span><h1>Turn old papers<br />into your next<br /><i>big win.</i></h1><p>Know what to focus on. Practice with a purpose. Make every study session count.</p>
            <div className="auth-stat"><div className="mini-avatars"><span>J</span><span>A</span><span>M</span></div><span>Made for curious, ambitious learners.</span></div>
          </div>
          <span className="auth-story-foot">Your study library stays private to your account.</span>
          <div className="story-orbit story-orbit-one" /><div className="story-orbit story-orbit-two" />
        </section>
        <section className="auth-panel">
          <form className="auth-form" onSubmit={submitAuth}>
            <span className="eyebrow">{authMode === "login" ? "WELCOME BACK" : "START YOUR JOURNEY"}</span>
            <h2>{authMode === "login" ? "Good to see you." : "Your next chapter."}</h2>
            <p>{authMode === "login" ? "Sign in to pick up where you left off." : "Create your private study workspace."}</p>
            {error && <div className="inline-error" role="alert">{error}</div>}
            <label>Email address<input name="email" type="email" autoComplete="email" placeholder="you@school.edu" required /></label>
            <label>Password<input name="password" type="password" autoComplete={authMode === "login" ? "current-password" : "new-password"} minLength={10} placeholder="At least 10 characters" required /></label>
            <button className="button button-primary auth-submit" disabled={authBusy}>{authBusy ? <LoaderCircle className="spin" size={18} /> : authMode === "login" ? "Sign in to EduLite" : "Create my account"}<ArrowRight size={17} /></button>
            <p className="auth-switch">{authMode === "login" ? "New to EduLite?" : "Already have an account?"}<button type="button" onClick={() => { setError(""); setAuthMode(authMode === "login" ? "register" : "login"); }}>{authMode === "login" ? "Create an account" : "Sign in"}</button></p>
          </form>
        </section>
      </main>
    );
  }

  const currentSubject = subject;
  const firstName = user.email.split("@")[0].split(/[._-]/)[0] || "there";

  function renderHome() {
    return (
      <div className="view-stack">
        <div className="welcome-row">
          <div><span className="date-label">{todayLabel()}</span><h1>Hi, {firstName}<span className="greeting-wave">✳</span></h1><p>Ready to make today’s study session count?</p></div>
          <div className="welcome-avatar">{firstName.slice(0, 1).toUpperCase()}<i /></div>
        </div>
        <form className="dashboard-search" onSubmit={searchSubmit}><Search size={19} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search subjects, PYQs, or predicted topics..." aria-label="Search subjects, questions, or topics" /><button aria-label="Search"><ArrowRight size={18} /></button></form>
        <HeroBanner subject={currentSubject?.name ?? "your next subject"} onUpload={() => setTab("subjects")} />
        <StudyTimerCard
          totalSeconds={studyTimer.totalSeconds + elapsedStudySeconds(studyTimer, studyTimerNow)}
          sessionSeconds={studyTimer.sessionSeconds + elapsedStudySeconds(studyTimer, studyTimerNow)}
          running={studyTimer.startedAt !== null}
          onToggle={toggleStudyTimer}
          onReset={resetStudySession}
        />
        <SectionTitle eyebrow="A LITTLE HEAD START" title="For you" action={<button className="section-link" onClick={() => setTab("subjects")}>See all <ArrowRight size={15} /></button>} />
        <BentoGrid prediction={data.predictions[0]} paperCount={data.analytics.total_questions} onPractice={() => setTab("practice")} onResources={() => setTab("resources")} onAnalyze={() => setTab("subjects")} />
        <div className="dashboard-lower">
          <section className="surface-card chart-card"><SectionTitle eyebrow="YOUR LIBRARY" title="Topics across the years" action={<span className="quiet-link">Exam patterns</span>} /><TopicHeatmap analytics={data.analytics} /></section>
          <section className="surface-card chart-card"><SectionTitle eyebrow="PLAN WITH CONFIDENCE" title="Topics to keep in view" action={<span className="estimate-pill">ESTIMATES</span>} /><ProbabilityChart predictions={data.predictions} /><p className="estimate-note">Probability estimates are study signals, never exam guarantees.</p></section>
        </div>
        {data.recommendations.length > 0 && <section className="surface-card recommendation-card"><SectionTitle eyebrow="YOUR PRACTICE" title="Worth another look" /><div className="recommendation-list">{data.recommendations.map((item) => <div key={item.topic}><span>{item.topic}</span><p>{item.suggestion}</p><small>{item.needs_practice} to revisit</small></div>)}</div></section>}
      </div>
    );
  }

  function renderSubjects() {
    const query = search.trim().toLocaleLowerCase();
    const matchingTopics = query ? topics.filter((topicName) => topicName.toLocaleLowerCase().includes(query)) : [];
    const matchingQuestions = query ? data.questions.filter((question) =>
      `${question.text} ${question.topic} ${question.source}`.toLocaleLowerCase().includes(query),
    ) : [];
    return (
      <div className="view-stack">
        <div className="view-heading"><span className="eyebrow">YOUR SUBJECTS · ANALYZE</span><h1>See the patterns.<br /><i>Study the right things.</i></h1><p>Upload past papers, review extracted questions, and explore exam trends.</p></div>
        {query && <section className="surface-card search-results"><SectionTitle eyebrow="SEARCH THIS SUBJECT" title={`Results for “${search.trim()}”`} /><div className="search-result-list">
          {matchingTopics.map((topicName) => <button key={topicName} onClick={() => setSelectedTopic(topicName)}><span>TOPIC</span><strong>{topicName}</strong><ArrowRight size={15} /></button>)}
          {matchingQuestions.slice(0, 5).map((question) => <div key={question.id ?? question.text}><span>PAST QUESTION · {question.topic}</span><p>{question.text}</p></div>)}
          {!matchingTopics.length && !matchingQuestions.length && <span className="search-no-results">No matching topics or questions in {subject?.name ?? "this subject"}.</span>}
        </div></section>}
        <div className="analyze-stats">
          <div className="surface-card mini-stat"><span>Questions analyzed</span><strong>{data.analytics.total_questions}</strong><small>Across your library</small></div>
          <div className="surface-card mini-stat"><span>Exam years</span><strong>{data.analytics.years.length || "—"}</strong><small>{data.analytics.years.length ? `${data.analytics.years[0]}–${data.analytics.years.at(-1)}` : "Add a dated paper"}</small></div>
          <div className="surface-card mini-stat"><span>Syllabus topics</span><strong>{topics.length}</strong><small>Ready to explore</small></div>
          <div className="surface-card mini-stat"><span>Needs a quick check</span><strong>{data.questions.filter((question) => question.needs_review).length}</strong><small>Low confidence extracts</small></div>
        </div>
        <div className={`upload-zone ${dragging ? "drag-active" : ""}`} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={handleDrop}>
          <div className="upload-illustration"><Upload size={23} /></div><div className="upload-text"><strong>Drop your past papers here</strong><span>or choose files from your device</span><small>{FORMAT_LABEL} · Up to 20 MB per file</small></div>
          <label htmlFor={fileInputId} className="button button-primary upload-button"><Plus size={16} /> Choose files</label>
          <input id={fileInputId} type="file" className="visually-hidden" accept={FILE_ACCEPT} multiple onChange={(event: ChangeEvent<HTMLInputElement>) => { if (event.target.files) void uploadFiles(event.target.files); event.target.value = ""; }} />
        </div>
        {uploadStatus && <div className={`upload-feedback ${uploadIsError ? "is-error" : ""}`} role={uploadIsError ? "alert" : "status"}>{uploadIsError ? <X size={17} /> : busy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}{uploadStatus}</div>}
        {preview.length > 0 && <form className="surface-card review-card" onSubmit={savePreview}>
          <div className="review-heading"><div><span className="eyebrow">EXTRACTION REVIEW</span><h2>Check the questions we found</h2><p>We haven’t added them to your library yet. Review, edit, and save below.</p></div><button className="button button-primary" disabled={busy}><Check size={16} /> Save {preview.filter((item) => item.included !== false).length} questions</button></div>
          <div className="review-list">{preview.map((question, index) => <article className="question-review" key={`${question.source}-${index}`}>
            <div className="question-review-top"><label className="include-toggle"><input type="checkbox" checked={question.included !== false} onChange={(event) => updatePreview(index, { included: event.target.checked })} /><span>Include</span></label><span className={`confidence-tag ${(question.confidence ?? 0) < 0.6 ? "low" : ""}`}>{Math.round((question.confidence ?? 0) * 100)}% confidence</span></div>
            <textarea value={question.text} onChange={(event) => updatePreview(index, { text: event.target.value })} aria-label={`Question ${index + 1} text`} />
            <div className="question-fields">
              <label>Topic<select value={question.topic} onChange={(event) => updatePreview(index, { topic: event.target.value })}>{topics.map((topicName) => <option key={topicName}>{topicName}</option>)}</select></label>
              <label>Year<input type="number" min="1900" max="2200" value={question.year ?? ""} onChange={(event) => updatePreview(index, { year: Number(event.target.value) || null })} /></label>
              <label>Marks<input type="number" min="0" max="100" step="0.5" value={question.marks ?? ""} onChange={(event) => updatePreview(index, { marks: Number(event.target.value) || null })} /></label>
              <label>Type<select value={question.question_type} onChange={(event) => updatePreview(index, { question_type: event.target.value })}>{["MCQ", "Short Answer", "Long Answer", "Numerical", "Code"].map((type) => <option key={type}>{type}</option>)}</select></label>
              <label>Difficulty<select value={question.difficulty} onChange={(event) => updatePreview(index, { difficulty: event.target.value })}>{["Easy", "Medium", "Hard"].map((level) => <option key={level}>{level}</option>)}</select></label>
            </div>
            <span className="source-caption"><FileText size={13} /> {question.source}</span>
          </article>)}</div>
          <div className="review-footer"><span>Saving adds selected questions to your private library and analytics.</span><button className="button button-primary" disabled={busy}><Check size={16} /> Save to my library</button></div>
        </form>}
        <div className="analyze-grid">
          <section className="surface-card chart-card"><SectionTitle eyebrow="APPEARANCE BY YEAR" title="Your topic heatmap" /><TopicHeatmap analytics={data.analytics} /></section>
          <section className="surface-card chart-card"><SectionTitle eyebrow="NEXT EXAM · ESTIMATES" title="What to keep in view" /><ProbabilityChart predictions={data.predictions} /></section>
        </div>
        <section className="surface-card library-section"><SectionTitle eyebrow="YOUR QUESTION LIBRARY" title={`${data.questions.length} questions`} action={<span className="quiet-link">Saved to this subject</span>} />
          {data.questions.length ? <div className="saved-question-list">{data.questions.map((question) => <article className="saved-question" key={question.id}>
            <textarea defaultValue={question.text} aria-label="Edit saved question text" onChange={(event) => { const id = question.id; if (id) setData((current) => ({ ...current, questions: current.questions.map((item) => item.id === id ? { ...item, text: event.target.value } : item) })); }} />
            <div className="saved-question-meta"><span>{question.topic}</span><span>{question.year ?? "Year unknown"}</span><span>{question.marks ?? "—"} marks</span><span>{question.difficulty}</span>{question.needs_review && <button className="text-action" onClick={() => void updateQuestion(question)}>Save edit</button>}</div>
          </article>)}</div> : <div className="chart-empty">Questions saved from reviewed uploads will appear here.</div>}
        </section>
      </div>
    );
  }

  function renderPractice() {
    const numericalVideoTopics = [...new Set([
      ...practiceSelectedTopics,
      practiceCustomTopic.trim(),
    ].filter(Boolean))];
    return (
      <div className="view-stack">
        <div className="view-heading"><span className="eyebrow">AI TUTOR · PRACTICE</span><h1>Practice with a<br /><i>little more purpose.</i></h1><p>Build an original exam-style paper from your syllabus and past-question patterns.</p></div>
        {renderExternalTutorSearch()}
        <form className="surface-card generator-form" onSubmit={generatePaper}>
          <div className="generator-title"><div className="generator-icon"><Sparkles size={20} /></div><div><h2>Your practice paper</h2><p>Pick your focus and we’ll put together a useful set.</p></div><span className="ai-tag">RAG-ASSISTED</span></div>
          <div className="generator-fields">
            <label>Questions<select name="count" defaultValue="5">{[3, 5, 8, 10, 15, 20].map((count) => <option key={count} value={count}>{count} questions</option>)}</select></label>
            <label>Marks each<select name="marks" defaultValue="5">{[2, 5, 8, 10, 15].map((marks) => <option key={marks} value={marks}>{marks} marks</option>)}</select></label>
            <label>Question type<select name="type" value={practiceQuestionType} onChange={(event) => setPracticeQuestionType(event.target.value)}>{["Any", "MCQ", "Short Answer", "Long Answer", "Numerical", "Code"].map((type) => <option key={type}>{type}</option>)}</select></label>
            <label>Difficulty<select name="difficulty" defaultValue="Medium">{["Easy", "Medium", "Hard"].map((level) => <option key={level}>{level}</option>)}</select></label>
          </div>
          <div className="topic-select-title"><strong>What should we focus on?</strong><span>Select one or more topics</span></div>
          <div className="topic-chips">{topics.map((topicName) => <label key={topicName}><input type="checkbox" name="topic" value={topicName} checked={practiceSelectedTopics.includes(topicName)} onChange={(event) => setPracticeSelectedTopics((current) => event.target.checked ? [...current, topicName] : current.filter((item) => item !== topicName))} /><span>{topicName}</span></label>)}</div>
          <label className="custom-practice-topic">Or enter any computer topic
            <input value={practiceCustomTopic} maxLength={160} onChange={(event) => setPracticeCustomTopic(event.target.value)} placeholder="e.g. binary subtraction, subnetting, SQL queries" aria-label="Enter a custom computer topic" />
          </label>
          {practiceQuestionType === "Numerical" && numericalVideoTopics.length > 0 && <section className="numerical-video-suggestions" aria-live="polite">
            <strong>Numerical practice videos</strong>
            <p>Find worked numerical examples for your selected computer topics:</p>
            <div className="resource-web-links">{numericalVideoTopics.map((topicName) => <a className="button button-soft" href={youtubeNumericalSearchUrl(topicName)} key={topicName} target="_blank" rel="noopener noreferrer"><ExternalLink size={14} /> {topicName} numericals on YouTube</a>)}</div>
          </section>}
          <div className="generator-submit"><p><Sparkles size={15} /> Each question is checked for topic fit and similarity to your past papers.</p><button className="button button-primary" disabled={busy}>{busy ? <LoaderCircle className="spin" size={17} /> : <Sparkles size={16} />} Generate practice set <ArrowRight size={16} /></button></div>
        </form>
        {paper && <section className="surface-card paper-output">
          <div className="paper-output-heading"><div><span className="eyebrow">YOUR NEW PRACTICE SET</span><h2>{paper.title}</h2><p>{paper.questions.length} original exam-style questions · Estimates, not predictions</p></div><div className="paper-export"><button className="button button-soft" onClick={() => void exportPaper("pdf")}><ArrowDownToLine size={15} /> PDF</button><button className="button button-soft" onClick={() => void exportPaper("docx")}><ArrowDownToLine size={15} /> Word</button></div></div>
          <div className="paper-question-list">{paper.questions.map((question) => <article className="practice-question" key={question.question_number}>
            <div className="practice-meta"><span>{question.topic}</span><span>{question.marks} marks</span><span>{question.difficulty}</span></div><h3>{question.question_number}. {question.question}</h3>
            {question.options?.length ? <div className="mcq-options">{question.options.map((option, index) => { const value = ["A", "B", "C", "D"][index]; return <label key={option} className={attempted[question.question_number] === value ? "selected" : ""}><input type="radio" name={`answer-${question.question_number}`} value={value} onChange={() => setAttempted((current) => ({ ...current, [question.question_number]: value }))} />{option}</label>; })}</div> : <textarea className="answer-field" placeholder="Write your answer here…" value={attempted[question.question_number] ?? ""} onChange={(event) => setAttempted((current) => ({ ...current, [question.question_number]: event.target.value }))} />}
            <div className="answer-row"><button className="button button-soft" onClick={() => void submitAttempt(question.question_number, question.question_type)}>Check my answer</button><details><summary>View model answer <ChevronDown size={14} /></summary><p>{question.answer}</p></details></div>
          </article>)}</div>
        </section>}
        <section className="surface-card saved-papers"><SectionTitle eyebrow="YOUR HISTORY" title="Saved practice sets" />{data.papers.length ? data.papers.map((item) => <div key={item.id} className="saved-paper-row"><span><FileText size={17} /><strong>{item.title}</strong></span><small>{new Date(item.created_at).toLocaleDateString()}</small></div>) : <div className="chart-empty">Your generated papers will be saved here.</div>}</section>
      </div>
    );
  }

  function renderResources() {
    const topic = resourceTopic.trim();
    const topicResources = data.resources.filter((resource) => resource.topic === topic);
    const topicGuide = data.guides.find((item) => item.topic === topic);
    return (
      <div className="view-stack">
        <div className="view-heading"><span className="eyebrow">YOUR FREE STUDY HUB</span><h1>A few good notes<br /><i>go a long way.</i></h1><p>Trusted study links and quick revision guides, gathered around your syllabus.</p></div>
        <section className="surface-card resource-search-card">
          <div className="resource-controls"><label>Choose or enter a subject topic<input list="resource-topic-options" value={resourceTopic} maxLength={160} onChange={(event) => setResourceTopic(event.target.value)} placeholder="e.g. Binary trees" aria-label="Choose or enter a subject topic" /><datalist id="resource-topic-options">{topics.map((topicName) => <option key={topicName} value={topicName} />)}</datalist></label><label>Refine your search<div className="resource-search-input"><Search size={16} /><input value={searchTerms} maxLength={200} onChange={(event) => setSearchTerms(event.target.value)} placeholder="e.g. free lectures, examples" /></div></label><button className="button button-primary" onClick={() => void discoverResources()} disabled={busy || !topic}>{busy ? <LoaderCircle className="spin" size={16} /> : <Search size={16} />} Find resources</button></div>
          <div className="source-note"><Check size={14} /> Free learning resources from trusted education domains. <span>Google Programmable Search or DuckDuckGo</span></div>
          {resourceSearchLinks?.topic === topic && <div className="resource-web-links" aria-label="More topic search options"><a className="button button-soft" href={resourceSearchLinks.google} target="_blank" rel="noopener noreferrer"><ExternalLink size={14} /> More free resources on Google</a><a className="button button-soft" href={resourceSearchLinks.youtube} target="_blank" rel="noopener noreferrer"><ExternalLink size={14} /> YouTube playlists</a></div>}
        </section>
        <div className="resource-grid">
          <section className="surface-card resource-results"><SectionTitle eyebrow="CURATED FOR YOUR TOPIC" title={topic || "Choose or enter a topic"} action={<span className="estimate-pill">OPEN ACCESS</span>} />
            {topicResources.length ? <div className="curated-list">{topicResources.map((resource) => <article className="curated-resource" key={resource.id}><div className="resource-logo"><FileText size={19} /></div><div><span className="resource-domain">{resource.domain}</span><a href={resource.url} target="_blank" rel="noopener noreferrer">{resource.title} <ArrowRight size={13} /></a><p>{resource.description}</p></div><button className={`bookmark-button ${resource.bookmarked ? "saved" : ""}`} onClick={() => void toggleBookmark(resource)} aria-label={resource.bookmarked ? "Remove bookmark" : "Bookmark resource"}><Bookmark size={18} fill={resource.bookmarked ? "currentColor" : "none"} /></button></article>)}</div> : <div className="chart-empty resource-empty"><FileImage size={28} /><strong>Your next great resource is one search away.</strong><span>Choose a syllabus topic or enter your own to find trusted free reading.</span></div>}
          </section>
          <section className="study-note"><div className="note-paper"><div className="note-paper-top"><span>EDULITE · QUICK NOTES</span><Sparkles size={15} /></div><span className="note-topic">{topic || "STUDY GUIDE"}</span><h2>Keep the key ideas<br />close at hand.</h2><div className="note-lines"><i /><i /><i /><i /></div><span className="note-doodle">✳</span></div><div className="study-note-copy"><span className="eyebrow">YOUR AI CHEAT SHEET</span><h3>{topicGuide?.topic ?? topic ?? "Quick revision guide"}</h3><div className="study-guide-text">{guide || topicGuide?.content || "Find resources to create concise, exam-oriented revision notes with key definitions, examples and a quick-review checklist."}</div><div className="paper-export"><button className="button button-soft" onClick={() => void exportNotes("pdf")}><ArrowDownToLine size={15} /> Export PDF</button><button className="button button-soft" onClick={() => void exportNotes("docx")}><ArrowDownToLine size={15} /> Export Word</button></div></div></section>
        </div>
      </div>
    );
  }

  return (
    <>
      <AppShell activeTab={tab} onNavigate={setTab} onLogout={signOut} onSearch={setSearch} searchValue={search} subjects={subjects} subjectId={subjectId} onSubjectChange={setSubjectId} user={user}>
        {error && <div className="global-error" role="alert"><span>{error}</span><button onClick={() => setError("")} aria-label="Dismiss error"><X size={17} /></button></div>}
        {!subjects.length ? <div className="no-subject-card"><span className="eyebrow">START YOUR STUDY WORKSPACE</span><h1>Choose what you’re<br /><i>learning next.</i></h1><p>Create a subject and add its syllabus to start building your exam plan.</p><button className="button button-primary" onClick={() => setSubjectDialog(true)}><Plus size={16} /> Create a subject</button>{renderExternalTutorSearch()}</div> : (
          <>
            {busy && <div className="busy-indicator"><LoaderCircle className="spin" size={15} /> Updating your workspace</div>}
            {tab === "home" && renderHome()}
            {tab === "subjects" && renderSubjects()}
            {tab === "practice" && renderPractice()}
            {tab === "resources" && renderResources()}
          </>
        )}
        {subjectDialog && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setSubjectDialog(false); }}><form className="subject-modal" onSubmit={createSubject}><button className="modal-close" type="button" aria-label="Close dialog" onClick={() => setSubjectDialog(false)}><X size={18} /></button><span className="eyebrow">YOUR NEW SUBJECT</span><h2>What are you studying?</h2><p>Add syllabus topics, one per line. You can edit them later.</p><label>Subject name<input name="name" minLength={2} maxLength={120} required placeholder="e.g. Data Structures" /></label><label>Syllabus topics<textarea name="syllabus" rows={5} maxLength={100000} placeholder={"Trees and Graphs\nSorting and Searching"} /></label><button className="button button-primary" type="submit"><Plus size={16} /> Create subject</button></form></div>}
      </AppShell>
      {toast && <div className="toast-message" role="status"><Check size={17} />{toast}<button onClick={() => setToast("")} aria-label="Dismiss notification"><X size={15} /></button></div>}
    </>
  );
}
