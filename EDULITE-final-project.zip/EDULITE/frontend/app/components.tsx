"use client";

import {
  BookOpen,
  BrainCircuit,
  ChevronDown,
  Clock3,
  House,
  Library,
  LogOut,
  Menu,
  Pause,
  Play,
  Search,
  Sparkles,
  RotateCcw,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ReactNode } from "react";
import type { Analytics, Prediction, Subject, Tab, User } from "./types";

const navigation: Array<{ id: Tab; label: string; icon: typeof House }> = [
  { id: "home", label: "Home", icon: House },
  { id: "subjects", label: "Analyze", icon: BookOpen },
  { id: "practice", label: "AI Tutor", icon: Sparkles },
  { id: "resources", label: "Resources", icon: Library },
];

export function AppShell({
  activeTab,
  children,
  onNavigate,
  onLogout,
  onSearch,
  onSubjectChange,
  searchValue,
  subjects,
  subjectId,
  user,
}: {
  activeTab: Tab;
  children: ReactNode;
  onNavigate: (tab: Tab) => void;
  onLogout: () => void;
  onSearch: (value: string) => void;
  onSubjectChange: (id: number) => void;
  searchValue: string;
  subjects: Subject[];
  subjectId: number | null;
  user: User;
}) {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#" aria-label="EduLite home">
          <span className="brand-mark"><Sparkles size={18} /></span>
          <span>edu<span>lite</span></span>
        </a>
        <p className="rail-label">YOUR WORKSPACE</p>
        <nav className="rail-nav" aria-label="Main navigation">
          {navigation.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`rail-link ${activeTab === id ? "active" : ""}`} onClick={() => onNavigate(id)}>
              <Icon size={19} strokeWidth={2} /><span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-tip">
            <span className="tip-spark"><Sparkles size={16} /></span>
            <strong>One step at a time</strong>
            <p>Small, focused study sessions add up.</p>
          </div>
          <div className="profile-row">
            <span className="avatar">{user.email.slice(0, 1).toUpperCase()}</span>
            <span className="profile-copy"><strong>{user.email}</strong><small>Student workspace</small></span>
            <button className="logout-button" onClick={onLogout} aria-label="Sign out" title="Sign out"><LogOut size={17} /></button>
          </div>
        </div>
      </aside>
      <div className="main-column">
        <header className="topbar">
          <div className="mobile-brand"><span className="brand-mark"><Sparkles size={17} /></span><strong>edulite</strong></div>
          <label className="global-search">
            <Search size={18} />
            <input value={searchValue} onChange={(event) => onSearch(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") onNavigate("subjects"); }} placeholder="Search subjects, PYQs, or topics..." aria-label="Search subjects and topics" />
          </label>
          <div className="header-actions">
            <label className="subject-picker" aria-label="Choose a subject">
              <BookOpen className="subject-picker-icon" size={16} />
              <select aria-label="Choose a subject" value={subjectId ?? ""} onChange={(event) => onSubjectChange(Number(event.target.value))}>
                {subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}
              </select>
              <ChevronDown className="subject-picker-chevron" size={13} />
            </label>
            <span className="avatar avatar-header">{user.email.slice(0, 1).toUpperCase()}</span>
            <button className="mobile-menu" onClick={onLogout} aria-label="Sign out"><Menu size={19} /></button>
          </div>
        </header>
        <main className="page-content">{children}</main>
      </div>
      <nav className="bottom-nav" aria-label="Mobile navigation">
        {navigation.map(({ id, label, icon: Icon }) => (
          <button key={id} className={activeTab === id ? "active" : ""} onClick={() => onNavigate(id)}>
            <Icon size={20} strokeWidth={activeTab === id ? 2.4 : 1.8} /><span>{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

export function HeroBanner({ subject, onUpload }: { subject: string; onUpload: () => void }) {
  return (
    <section className="hero-banner">
      <div className="hero-copy">
        <span className="hero-eyebrow"><Sparkles size={14} /> YOUR NEXT STUDY SESSION</span>
        <h2>Which exam are you<br className="desktop-break" /> preparing for today?</h2>
        <p>Turn old papers into a clearer plan for what to learn next.</p>
        <button className="button button-white" onClick={onUpload}>Upload past papers <span aria-hidden="true">↗</span></button>
        <span className="hero-subject">Currently studying <strong>{subject}</strong></span>
      </div>
      <div className="hero-art" aria-hidden="true">
        <div className="art-sun" />
        <div className="art-book art-book-one" />
        <div className="art-book art-book-two" />
        <div className="art-person"><div className="art-hair" /><div className="art-face" /><div className="art-body" /><div className="art-arm" /></div>
        <div className="art-laptop"><div /></div>
        <div className="art-cap"><span /></div>
        <div className="art-spark art-spark-one">✦</div><div className="art-spark art-spark-two">✳</div>
      </div>
      <div className="hero-wave" />
    </section>
  );
}

export function BentoGrid({
  prediction,
  paperCount,
  onPractice,
  onResources,
  onAnalyze,
}: {
  prediction?: Prediction;
  paperCount: number;
  onPractice: () => void;
  onResources: () => void;
  onAnalyze: () => void;
}) {
  return (
    <div className="bento-grid">
      <article className="featured-topic">
        <span className="featured-label"><Sparkles size={14} /> TOP PREDICTED TOPIC</span>
        <div className="featured-probability">{prediction?.probability_percent ?? 0}<span>%</span></div>
        <h3>{prediction?.topic ?? "Build your prediction"}</h3>
        <p>{prediction?.reasoning ?? "Add previous-year papers to see your topic forecast."}</p>
        <div className="featured-bottom"><span>Estimated · not guaranteed</span><button aria-label="Practice this topic" onClick={onPractice}><Sparkles size={19} /></button></div>
        <div className="featured-decoration" aria-hidden="true">✦</div>
      </article>
      <button className="bento-card generator-card" onClick={onPractice}>
        <span className="bento-icon blue-icon"><BrainCircuit size={19} /></span>
        <span className="bento-overline">AI PRACTICE STUDIO</span>
        <strong>Build a paper<br />that fits your exam</strong>
        <span className="bento-foot">Choose topic, marks and difficulty <span>↗</span></span>
      </button>
      <button className="bento-card resource-card" onClick={onResources}>
        <span className="note-preview"><span>STUDY NOTE · 5 MIN READ</span><strong>Quick revision<br />starts here.</strong><i>01 — CONCEPTS</i></span>
        <span className="resource-card-copy"><span>CURATED FOR YOU</span><strong>Fresh notes, trusted sources</strong><span>Explore study materials <span>↗</span></span></span>
      </button>
      <button className="bento-card library-card" onClick={onAnalyze}>
        <span className="library-icon"><BookOpen size={19} /></span>
        <span><strong>Your PYQ library</strong><small>{paperCount} questions analyzed · Explore patterns</small></span>
        <span className="library-arrow">↗</span>
      </button>
    </div>
  );
}

export function StudyTimerCard({
  totalSeconds,
  sessionSeconds,
  running,
  onToggle,
  onReset,
}: {
  totalSeconds: number;
  sessionSeconds: number;
  running: boolean;
  onToggle: () => void;
  onReset: () => void;
}) {
  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remaining = seconds % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(remaining).padStart(2, "0")}`;
  };

  return (
    <section className="study-timer-card" aria-label="Study hour counter">
      <div className="study-timer-icon"><Clock3 size={20} /></div>
      <div className="study-timer-copy">
        <span className="eyebrow">YOUR FOCUS TIME</span>
        <strong aria-live="off">{formatTime(totalSeconds)}</strong>
        <span className="study-timer-caption">Total study time · {formatTime(sessionSeconds)} this session</span>
      </div>
      <div className="study-timer-controls">
        <button className="button button-primary timer-toggle" onClick={onToggle} aria-label={running ? "Pause study timer" : "Start study timer"}>
          {running ? <Pause size={15} /> : <Play size={15} fill="currentColor" />}
          {running ? "Pause" : "Start studying"}
        </button>
        <button className="timer-reset" onClick={onReset} disabled={sessionSeconds === 0 && !running} aria-label="Reset current study session" title="Reset current session">
          <RotateCcw size={15} /><span>Reset session</span>
        </button>
      </div>
    </section>
  );
}

export function TopicHeatmap({ analytics }: { analytics: Analytics }) {
  if (!analytics.years.length || !analytics.topic_matrix.length) {
    return <div className="chart-empty">Upload papers with exam years to build your topic heatmap.</div>;
  }
  return (
    <div className="heatmap-scroll">
      <table className="heatmap-table">
        <thead><tr><th>Topic</th>{analytics.years.map((year) => <th key={year}>{year}</th>)}</tr></thead>
        <tbody>
          {analytics.topic_matrix.map((row, index) => (
            <tr key={`${row.topic}-${index}`}><th>{String(row.topic)}</th>{analytics.years.map((year) => (
              <td key={year}><span className={`heat-cell ${row[String(year)] ? "on" : ""}`} title={`${String(row.topic)} · ${year}: ${row[String(year)] ? "appeared" : "not recorded"}`} /></td>
            ))}</tr>
          ))}
        </tbody>
      </table>
      <div className="heatmap-legend"><span>Less</span><i /><i /><i /><i /><span>More appearances</span></div>
    </div>
  );
}

export function ProbabilityChart({ predictions }: { predictions: Prediction[] }) {
  if (!predictions.length) return <div className="chart-empty">Add previous-year questions to estimate topic coverage.</div>;
  const chartData = predictions.slice(0, 6);
  return (
    <div className="probability-chart-wrap">
      <ResponsiveContainer width="100%" height={Math.max(174, chartData.length * 39)}>
        <BarChart data={chartData} layout="vertical" margin={{ top: 3, right: 12, bottom: 3, left: 2 }} barCategoryGap={10} accessibilityLayer>
          <CartesianGrid horizontal={false} stroke="#eef1f6" strokeDasharray="3 4" />
          <XAxis type="number" domain={[0, 100]} hide />
          <YAxis type="category" dataKey="topic" width={116} axisLine={false} tickLine={false} tick={{ fill: "#64748b", fontSize: 9 }} />
          <Tooltip cursor={{ fill: "#f7f9ff" }} formatter={(value) => [`${value}%`, "Estimate"]} contentStyle={{ border: "1px solid #e8edf4", borderRadius: 10, fontSize: 10 }} />
          <Bar dataKey="probability_percent" name="Estimate" radius={[0, 8, 8, 0]} maxBarSize={15}>
            {chartData.map((item, index) => <Cell key={item.topic} fill={index === 0 ? "#43a047" : "#547af1"} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div className="probability-reasons">{chartData.slice(0, 4).map((item) => <p key={item.topic}><span>{item.probability_percent}% · {item.topic}</span>{item.reasoning}</p>)}</div>
    </div>
  );
}

export function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return <div className="section-title"><div>{eyebrow && <span>{eyebrow}</span>}<h2>{title}</h2></div>{action}</div>;
}
