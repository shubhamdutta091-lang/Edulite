import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EduLite — Study smarter",
  description: "Turn past papers into a clearer picture of what to study next.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
