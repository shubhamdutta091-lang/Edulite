import re
import uuid

from backend.models import Question, Subject

DEFAULT_TOPICS = {
    "Data Structures": ["Arrays and Linked Lists", "Trees and Graphs", "Sorting and Searching", "Stacks and Queues", "Hashing"],
    "DBMS": ["Relational Model and SQL", "Normalization", "Transactions and Concurrency", "Indexing", "Database Design"],
    "Operating Systems": ["Process Management", "Memory Management", "File Systems", "Synchronization", "CPU Scheduling"],
    "Computer Networks": ["OSI and TCP/IP Models", "Routing", "Transport Layer", "Network Security", "Data Link Layer"],
}


def get_topics(subject: Subject) -> list[str]:
    topics = [line.strip(" -#0123456789.)\t") for line in subject.syllabus.splitlines() if line.strip()]
    if not topics:
        topics = DEFAULT_TOPICS.get(subject.name, [subject.name])
    return list(dict.fromkeys(topic[:160] for topic in topics))[:100]


def classify_question(text: str, subject: Subject) -> dict:
    normalized = text.lower()
    scored = []
    for topic in get_topics(subject):
        words = re.findall(r"[a-z0-9]+", topic.lower())
        score = sum(1 for word in words if len(word) > 2 and word in normalized)
        scored.append((score, topic))
    best_score, topic = max(scored, default=(0, subject.name))
    if best_score == 0:
        topic = get_topics(subject)[0]
    if re.search(r"\b(a|b|c|d)\s*[\).]\s", normalized) or re.search(r"\bchoose the correct\b", normalized):
        question_type = "MCQ"
    elif re.search(r"\b(write|implement|code|program|algorithm)\b", normalized):
        question_type = "Code"
    elif re.search(r"\b(calculate|compute|solve|find the value|numerical)\b", normalized):
        question_type = "Numerical"
    elif len(text.split()) < 35:
        question_type = "Short Answer"
    else:
        question_type = "Long Answer"
    complexity = len(text.split()) + 8 * len(re.findall(r"\b(prove|derive|analyze|compare|design)\b", normalized))
    difficulty = "Easy" if complexity < 20 else "Hard" if complexity > 55 else "Medium"
    return {
        "topic": topic,
        "question_type": question_type,
        "difficulty": difficulty,
        "confidence": round(min(0.95, 0.45 + best_score * 0.14), 2) if best_score else 0.42,
    }


def family_id_for(text: str) -> str:
    tokens = sorted(set(re.findall(r"[a-z0-9]+", text.lower())) - {"the", "a", "an", "and", "of", "to", "in"})
    return uuid.uuid5(uuid.NAMESPACE_URL, " ".join(tokens)).hex[:16]


def similar_question_score(first: str, second: str) -> float:
    from difflib import SequenceMatcher

    normalized_first = re.sub(r"\W+", " ", first.lower()).strip()
    normalized_second = re.sub(r"\W+", " ", second.lower()).strip()
    if normalized_first and normalized_second:
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.metrics.pairwise import cosine_similarity

            vectors = TfidfVectorizer(ngram_range=(1, 2), stop_words="english").fit_transform(
                [normalized_first, normalized_second]
            )
            return float(cosine_similarity(vectors[0:1], vectors[1:2])[0][0])
        except ValueError:
            pass
    return SequenceMatcher(None, normalized_first, normalized_second).ratio()


def duplicate_groups(questions: list[Question], threshold: float = 0.82) -> list[list[int]]:
    if len(questions) < 2:
        return []
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity

        matrix = TfidfVectorizer(stop_words="english", ngram_range=(1, 2)).fit_transform(
            [question.text for question in questions]
        )
        neighbors = (
            (index, index + offset + 1, float(score))
            for index in range(len(questions) - 1)
            for offset, score in enumerate(cosine_similarity(matrix[index:index + 1], matrix[index + 1:]).ravel())
        )
    except ValueError:
        neighbors = (
            (index, other_index, similar_question_score(questions[index].text, questions[other_index].text))
            for index in range(len(questions) - 1)
            for other_index in range(index + 1, len(questions))
        )
    parents = list(range(len(questions)))

    def find(index: int) -> int:
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    for first, second, score in neighbors:
        if score >= threshold:
            parents[find(second)] = find(first)
    components: dict[int, list[int]] = {}
    for index, question in enumerate(questions):
        root = find(index)
        components.setdefault(root, []).append(question.id)
    return [group for group in components.values() if len(group) > 1]
