from backend.models import Question, Subject
from ml_pipeline.classification import similar_question_score
from ml_pipeline.vector_store import QuestionVectorStore


def retrieve_questions(
    query: str,
    questions: list[Question],
    limit: int = 5,
    store: QuestionVectorStore | None = None,
) -> list[Question]:
    if not questions:
        return []
    try:
        store = store or QuestionVectorStore([question.text for question in questions])
        matches = store.search(query, limit)
        if matches:
            return [questions[index] for index, _ in matches]
    except ValueError:
        pass
    ranked = sorted(questions, key=lambda item: similar_question_score(query, item.text), reverse=True)
    return ranked[:limit]


def retrieve_context(
    query: str,
    subject: Subject,
    questions: list[Question],
    limit: int = 5,
    external_context: list[dict] | None = None,
    question_store: QuestionVectorStore | None = None,
) -> list[dict]:
    context = []
    for index, line in enumerate(subject.syllabus.splitlines()):
        if line.strip():
            score = similar_question_score(query, line)
            context.append({"text": f"Syllabus: {line.strip()}", "source": f"syllabus section {index + 1}", "score": score})
    question_matches = retrieve_questions(query, questions, limit, question_store)
    for question in question_matches:
        context.append({
            "text": question.text,
            "source": f"PYQ #{question.id}" + (f" ({question.year})" if question.year else ""),
            "score": similar_question_score(query, question.text),
        })
    for resource in external_context or []:
        context.append({
            "text": f"{resource['title']}: {resource['description']}",
            "source": resource["url"],
            "score": similar_question_score(query, f"{resource['title']} {resource['description']}"),
        })
    return sorted(context, key=lambda item: item["score"], reverse=True)[:limit]
