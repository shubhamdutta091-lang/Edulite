import json
import re
import urllib.error
import urllib.request

from backend.config import settings
from backend.models import Question, Subject
from ml_pipeline.classification import similar_question_score
from ml_pipeline.retrieval import retrieve_context
from ml_pipeline.vector_store import QuestionVectorStore

TOPIC_ANSWERS = (
    (("tree", "graph", "traversal"), "A tree is a connected acyclic graph; a binary search tree orders keys so left-subtree keys are smaller and right-subtree keys are larger. Breadth-first search visits vertices level by level with a queue, while depth-first search follows a path using a stack or recursion. With adjacency lists, both traversals run in O(V + E) time. A balanced search tree keeps its height O(log n), so search, insertion, and deletion are logarithmic."),
    (("sorting", "search"), "Binary search needs sorted input and halves the remaining search interval on each comparison, giving O(log n) search time. Merge sort divides and merges ordered halves in O(n log n) time with O(n) auxiliary space. Quicksort is typically O(n log n), but can degrade to O(n^2) with repeatedly poor pivots. The choice depends on stability, memory, and input characteristics."),
    (("stack", "queue"), "A stack is last-in, first-out and supports push and pop at the top; a queue is first-in, first-out and adds at the rear while removing from the front. Both operations are O(1) with a suitable linked or circular-array representation. Stacks support parsing and depth-first traversal; queues support scheduling and breadth-first traversal."),
    (("hash",), "A hash table maps a key to an array position using a hash function. Collisions can be handled by separate chaining or open addressing, and load factor affects expected performance. Search, insertion, and deletion are O(1) on average but can be O(n) in the worst case. A good hash distributes keys uniformly and equality is checked after locating a candidate."),
    (("normalization", "functional depend"), "Normalization reduces update anomalies by structuring relations around functional dependencies. First normal form requires atomic attribute values; second normal form removes partial dependency on a composite candidate key; third normal form removes transitive dependency of non-key attributes on a key. Decompose relations carefully and verify that joins are lossless and, where possible, dependencies are preserved."),
    (("transaction", "concurr", "acid"), "A transaction should satisfy atomicity, consistency, isolation, and durability. Isolation controls the visibility of concurrent operations; locking or multiversion concurrency control can prevent anomalies such as dirty reads. Commit makes a transaction durable, while rollback undoes its uncommitted changes. A schedule is safe when it preserves the database constraints and the required isolation level."),
    (("sql", "relational", "database design", "er model"), "The relational model represents data as relations with candidate keys and integrity constraints. SQL joins combine related rows, while grouping and aggregate functions summarize them. Database design should identify entities, keys, and relationships, then enforce referential integrity. Parameterized queries should be used in applications so data values are not interpreted as SQL syntax."),
    (("index", "indexing"), "An index is an auxiliary search structure that reduces the rows examined by a query, often using a B-tree for ordered access or a hash structure for equality lookup. A clustered index controls row organization; a non-clustered index stores keys and row references separately. Indexes improve reads but consume storage and add work to inserts, updates, and deletes. Select indexes based on measured query patterns."),
    (("process", "cpu scheduling", "scheduling"), "A process is a program in execution with state, registers, address space, and scheduling information. The scheduler selects a ready process; context switching saves one execution state and restores another. FCFS is simple but may cause convoying, round-robin improves responsiveness with a time quantum, and priority scheduling can starve low-priority jobs without aging. Compare waiting, turnaround, and response time."),
    (("memory", "virtual memory", "paging", "segmentation"), "Virtual memory gives each process a logical address space and maps pages to physical frames through page tables and the MMU. A TLB caches translations; a page fault occurs when a referenced page is not resident and may require replacement. Paging avoids external fragmentation but can cause internal fragmentation. Segmentation reflects logical regions and can suffer external fragmentation."),
    (("deadlock", "synchronization", "semaphore", "mutex"), "Deadlock requires mutual exclusion, hold-and-wait, no preemption, and circular wait to hold simultaneously. Prevention breaks at least one necessary condition; avoidance grants requests only when the resulting state is safe. For producer-consumer synchronization, a mutex protects the buffer and counting semaphores track empty and full slots. Every shared-state update must occur under the appropriate synchronization."),
    (("file system", "file systems"), "A file system names and stores files, tracks metadata and free space, and maps logical file offsets to storage blocks. Directories provide namespace organization; allocation can use contiguous, linked, or indexed structures. Journaling records updates so recovery can restore consistency after a crash. Access-control checks should be applied consistently to files and directories."),
    (("osi", "tcp/ip", "network model"), "The OSI model separates networking into physical, data-link, network, transport, session, presentation, and application layers. TCP/IP groups these responsibilities into link, internet, transport, and application layers. Encapsulation adds layer-specific headers as data moves down the stack, and decapsulation removes them at the receiver. The models are conceptual guides, not a requirement that every protocol map perfectly one-to-one."),
    (("tcp", "transport"), "TCP provides a reliable, ordered byte stream using sequence numbers, acknowledgements, retransmissions, and flow and congestion control. A three-way handshake exchanges SYN, SYN-ACK, and ACK to establish initial sequence state. UDP has lower connection overhead but does not itself guarantee delivery or order. Choose transport based on application requirements."),
    (("routing",), "Distance-vector routing shares route costs with neighbors and can converge slowly; link-state routing floods link information so each router computes shortest paths from a common topology view. Both use metrics and need mechanisms to handle topology changes. Loop prevention and convergence behavior matter as much as the chosen path cost."),
    (("subnet", "cidr", "data link", "error detection", "security"), "IPv4 CIDR uses a prefix length to divide network and host bits; a /p prefix in IPv4 leaves 32-p host bits. The network address has host bits cleared and the broadcast address has them set; traditional usable-host counts exclude both, with special cases for /31 and /32. Checksums detect many transmission errors but are not cryptographic integrity checks. Authentication and encryption require separate security protocols."),
)


def _extract_gemini_text(payload: dict | str) -> str:
    if isinstance(payload, str):
        text = payload.strip()
    elif isinstance(payload, dict):
        candidates = payload.get("candidates") or []
        parts = []
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            content = candidate.get("content") or {}
            for part in content.get("parts") or []:
                if isinstance(part, dict):
                    text_value = part.get("text")
                    if isinstance(text_value, str):
                        parts.append(text_value)
        text = "".join(parts)
    else:
        text = ""
    if not text:
        raise ValueError("Gemini returned no content.")
    match = re.search(r"```(?:json)?\s*(.*?)\s*```", text, flags=re.IGNORECASE | re.DOTALL)
    if match:
        text = match.group(1)
    return text.strip()


def _call_gemini(prompt: str) -> dict:
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
    payload = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.7},
    }).encode()
    request = urllib.request.Request(
        f"{url}?key={settings.gemini_api_key}",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            result = json.loads(response.read())
        text = _extract_gemini_text(result)
        return json.loads(text)
    except (urllib.error.URLError, TimeoutError, KeyError, IndexError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Gemini generation failed: {exc}") from exc


def _offline_question(topic: str, question_type: str, difficulty: str, index: int, marks: float) -> dict:
    scenario = f"scenario {index + 1}"
    prompts = [
        f"Explain the core principles of {topic} and show how they apply to a practical problem.",
        f"Analyze a representative {topic} scenario, compare two possible approaches, and justify the better choice.",
        f"Develop a worked example that demonstrates an important concept in {topic}, stating assumptions and steps.",
        f"Evaluate how a design decision in {topic} affects correctness, efficiency, and maintainability.",
        f"Describe a real-world application of {topic} and derive a reasoned solution to one challenge it presents.",
        f"Trace the steps in a {topic} solution and explain the purpose of each step.",
        f"State the assumptions behind a {topic} method and discuss when those assumptions do not hold.",
        f"Predict the outcome of a changed input in a {topic} problem and justify your reasoning.",
        f"Design a test case for a {topic} solution, including an edge case and expected result.",
        f"Contrast two approaches to {topic} and recommend one for a stated use case.",
        f"Propose a solution to a new {topic} challenge and explain its trade-offs.",
        f"Interpret a result obtained from a {topic} procedure and explain what it means.",
        f"Illustrate a key {topic} concept with a new example and explain why it works.",
        f"Identify a likely failure mode in a {topic} design and propose a practical remedy.",
        f"Design a small system that applies {topic}, then justify its main components.",
        f"Step through an edge case in {topic} and explain how a robust solution handles it.",
        f"Assess the efficiency of a {topic} strategy and identify one possible improvement.",
        f"Formulate a clear method for solving a {topic} problem and state its limitations.",
        f"Explain how you would verify the correctness of a {topic} implementation.",
        f"Justify a design choice in {topic} using correctness, efficiency, and maintainability.",
    ]
    stem = prompts[index % len(prompts)]
    if question_type == "MCQ":
        stem = f"Which option best addresses this {topic} challenge: {stem} Select one and justify your choice."
    elif question_type == "Numerical":
        stem = f"Construct a numerical example about {topic} for {scenario}, show the calculation steps, and give the result."
    elif question_type == "Code":
        stem = f"Write a small program for {scenario} that illustrates a central concept in {topic}. Explain it and state its complexity."
    topic_lower = topic.lower()
    answer_text = next(
        (answer for keywords, answer in TOPIC_ANSWERS if any(keyword in topic_lower for keyword in keywords)),
        f"A complete response should define the central terms in {topic}, state assumptions, show a correct method or example, and justify the conclusion using the relevant syllabus concepts.",
    )
    result = {
        "question": stem,
        "answer": answer_text,
        "mark_scheme": [
            {"criterion": f"Accurate explanation of {topic}", "marks": round(marks * 0.4, 2)},
            {"criterion": "Clear reasoning, method, or worked example", "marks": round(marks * 0.4, 2)},
            {"criterion": "Justified conclusion and correct terminology", "marks": round(marks * 0.2, 2)},
        ],
    }
    if question_type == "MCQ":
        result["options"] = [
            f"A. A sound application of a core {topic} principle",
            "B. Ignoring the stated assumptions",
            "C. Choosing a result without checking the method",
            "D. Applying an unrelated concept",
        ]
        result["correct_option"] = "A"
        result["answer"] = f"Correct option: A. {answer_text}"
    return result


def generate_questions(
    subject: Subject,
    questions: list[Question],
    topics: list[str],
    count: int,
    marks: float,
    question_type: str,
    difficulty: str,
    external_context: list[dict] | None = None,
) -> list[dict]:
    output = []
    question_store = QuestionVectorStore([question.text for question in questions]) if questions else None
    for index in range(count):
        topic = topics[index % len(topics)]
        context = retrieve_context(
            topic,
            subject,
            questions,
            limit=5,
            external_context=external_context,
            question_store=question_store,
        )
        if settings.gemini_api_key:
            prompt = (
                "Create exactly one original exam-style question and a factual model answer. Do not copy or closely "
                "paraphrase any prior question. Return JSON with keys question, answer, mark_scheme (array of "
                "{criterion, marks}); for MCQ also include options (array) and correct_option (A-D). "
                "The question must match the requested topic, type, difficulty and marks. "
                f"Topic: {topic}; subject: {subject.name}; type: {question_type}; difficulty: {difficulty}; marks: {marks}. "
                "Use syllabus/PYQ context only for factual grounding and style; do not cite or reproduce question text. "
                f"Context: {json.dumps([item['text'] for item in context], ensure_ascii=False)}"
            )
            generated = _call_gemini(prompt)
        else:
            generated = _offline_question(topic, question_type, difficulty, index, marks)
        text = str(generated.get("question", "")).strip()
        answer = str(generated.get("answer", "")).strip()
        if len(text) < 20 or len(answer) < 30:
            raise RuntimeError("The question generator returned incomplete question or answer content.")
        existing_matches = question_store.search(text, limit=1) if question_store is not None else []
        if (existing_matches and existing_matches[0][1] > 0.85) or any(
            similar_question_score(text, existing["question"]) > 0.85 for existing in output
        ):
            raise RuntimeError("A generated question was too similar to a stored PYQ. Try a different topic or prompt.")
        if topic.lower() not in text.lower():
            raise RuntimeError(f"Generated question did not align with the requested topic '{topic}'.")
        if question_type == "MCQ" and (
            len(generated.get("options", [])) != 4
            or generated.get("correct_option") not in {"A", "B", "C", "D"}
        ):
            raise RuntimeError("The MCQ generator must return four options and a valid correct option.")
        if re.search(r"\b(TODO|PLACEHOLDER)\b", text + answer, re.I):
            raise RuntimeError("The generated paper contains invalid placeholder content.")
        if settings.gemini_api_key:
            review = _call_gemini(
                "Act as an exam content reviewer. Check whether the proposed answer is consistent with the supplied "
                "context, addresses the requested topic and matches the stated difficulty. Return JSON with keys "
                "consistent (boolean), topic_aligned (boolean), difficulty_aligned (boolean), and reason (short string). "
                "Mark false if a factual claim is contradicted or unsupported.\n"
                f"Topic: {topic}\nDifficulty: {difficulty}\nQuestion: {text}\nAnswer: {answer}\nContext: "
                f"{json.dumps([item['text'] for item in context], ensure_ascii=False)}"
            )
            if (
                review.get("consistent") is not True
                or review.get("topic_aligned") is not True
                or review.get("difficulty_aligned") is not True
            ):
                raise RuntimeError(f"Answer consistency review failed: {review.get('reason', 'The answer needs review.')}")
        output.append({
            "question_number": index + 1,
            "topic": topic,
            "question": text,
            "answer": answer,
            "marks": marks,
            "difficulty": difficulty,
            "question_type": question_type if question_type != "Any" else "Long Answer",
            "options": generated.get("options", []),
            "correct_option": generated.get("correct_option"),
            "mark_scheme": generated.get("mark_scheme", []),
            "citations": list(dict.fromkeys(item["source"] for item in context)),
            "validation": {
                "duplicate_check": "passed",
                "topic_alignment": "passed",
                "difficulty_alignment": "secondary review passed" if settings.gemini_api_key else "requested level supplied; manual review recommended",
                "answer_review": "secondary Gemini review passed" if settings.gemini_api_key else (
                    "topic and answer completeness checked; verify factual claims against cited sources"
                ),
            },
        })
    return output
