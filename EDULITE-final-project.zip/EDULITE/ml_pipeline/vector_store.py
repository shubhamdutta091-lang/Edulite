from functools import lru_cache

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@lru_cache(maxsize=1)
def _sentence_model():
    from sentence_transformers import SentenceTransformer

    return SentenceTransformer("all-MiniLM-L6-v2")


class QuestionVectorStore:
    """Build a request-scoped semantic or TF-IDF vector index over visible PYQs."""

    def __init__(self, documents: list[str]):
        self.documents = documents
        self.model = None
        self.vectorizer = None
        self.matrix = None
        self.faiss_index = None
        if not documents:
            return
        try:
            import numpy as np

            self.model = _sentence_model()
            embeddings = self.model.encode(documents, normalize_embeddings=True, convert_to_numpy=True)
            self.matrix = np.asarray(embeddings, dtype="float32")
        except Exception:
            self.model = None
            self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
            self.matrix = self.vectorizer.fit_transform(documents)
        if self.matrix is not None:
            try:
                import faiss
                import numpy as np

                dense = self.matrix.toarray() if hasattr(self.matrix, "toarray") else self.matrix
                dense = np.ascontiguousarray(dense, dtype="float32")
                self.faiss_index = faiss.IndexFlatIP(dense.shape[1])
                self.faiss_index.add(dense)
            except ImportError:
                self.faiss_index = None

    def search(self, query: str, limit: int = 5) -> list[tuple[int, float]]:
        if self.matrix is None:
            return []
        if self.model is not None:
            try:
                import numpy as np

                query_vector = np.asarray(
                    self.model.encode([query], normalize_embeddings=True, convert_to_numpy=True),
                    dtype="float32",
                )
            except Exception:
                self.model = None
                if self.vectorizer is None:
                    self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
                    self.matrix = self.vectorizer.fit_transform(self.documents)
                query_vector = self.vectorizer.transform([query])
        else:
            query_vector = self.vectorizer.transform([query])
        if self.faiss_index is not None:
            import numpy as np

            dense_query = query_vector.toarray() if hasattr(query_vector, "toarray") else query_vector
            scores, indices = self.faiss_index.search(np.ascontiguousarray(dense_query, dtype="float32"), limit)
            return [(int(index), float(score)) for index, score in zip(indices[0], scores[0]) if index >= 0 and score > 0]
        scores = cosine_similarity(query_vector, self.matrix).ravel()
        ranking = sorted(enumerate(scores.tolist()), key=lambda pair: pair[1], reverse=True)
        return [(index, float(score)) for index, score in ranking[:limit] if score > 0]
