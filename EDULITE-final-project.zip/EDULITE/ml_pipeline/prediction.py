from collections import defaultdict
from statistics import mean

from backend.models import Question


def _features(
    presence: list[int],
    marks_by_period: list[list[float]],
    index: int,
    syllabus_weight: float,
) -> list[float]:
    history = presence[:index]
    recent = history[-3:]
    last_seen = max((i for i, present in enumerate(history) if present), default=-1)
    gap = index - last_seen if last_seen >= 0 else index + 1
    marks = [mark for period in marks_by_period[:index] for mark in period]
    return [
        sum(history) / max(len(history), 1),
        sum(recent) / max(len(recent), 1),
        float(gap),
        float(history[-1]) if len(history) >= 1 else 0.0,
        float(history[-2]) if len(history) >= 2 else 0.0,
        float(history[-3]) if len(history) >= 3 else 0.0,
        mean(marks) if marks else 0.0,
        syllabus_weight,
    ]


def predict_topics(questions: list[Question], syllabus_topics: list[str]) -> list[dict]:
    years = sorted({question.year for question in questions if question.year is not None})
    by_year_topic: dict[tuple[int, str], list[Question]] = defaultdict(list)
    topic_questions: dict[str, list[Question]] = defaultdict(list)
    for question in questions:
        topic_questions[question.topic].append(question)
        if question.year is not None:
            by_year_topic[(question.year, question.topic)].append(question)
    topics = list(dict.fromkeys(syllabus_topics + list(topic_questions)))
    histories: dict[str, list[int]] = {}
    topic_marks: dict[str, list[list[float]]] = {}
    for topic in topics:
        history = [int(any(key[0] == year and key[1] == topic for key in by_year_topic)) for year in years]
        histories[topic] = history
        topic_marks[topic] = [
            [q.marks for q in by_year_topic[(year, topic)] if q.marks is not None]
            for year in years
        ]

    training_x, training_y, training_years = [], [], []
    for index in range(1, len(years)):
        for topic in topics:
            history = histories[topic]
            training_x.append(_features(history, topic_marks[topic], index, 1 / max(len(topics), 1)))
            training_y.append(history[index])
            training_years.append(index)

    rolling_origin = {"folds": 0, "accuracy": None, "brier_score": None}
    unique_training_years = sorted(set(training_years))
    if len(training_x) >= 20 and len(unique_training_years) >= 4:
        try:
            from sklearn.linear_model import LogisticRegression
            from sklearn.metrics import accuracy_score, brier_score_loss
            from sklearn.model_selection import TimeSeriesSplit
            from xgboost import XGBClassifier

            fold_accuracies = []
            fold_brier_scores = []
            splitter = TimeSeriesSplit(n_splits=min(3, len(unique_training_years) - 1))
            for train_positions, test_positions in splitter.split(unique_training_years):
                train_years = {unique_training_years[position] for position in train_positions}
                test_years = {unique_training_years[position] for position in test_positions}
                train_rows = [i for i, year_index in enumerate(training_years) if year_index in train_years]
                test_rows = [i for i, year_index in enumerate(training_years) if year_index in test_years]
                fold_x = [training_x[i] for i in train_rows]
                fold_y = [training_y[i] for i in train_rows]
                if len(set(fold_y)) != 2 or not test_rows:
                    continue
                fold_models = [
                    LogisticRegression(class_weight="balanced", max_iter=500, random_state=17),
                    XGBClassifier(
                        n_estimators=80,
                        max_depth=2,
                        learning_rate=0.05,
                        eval_metric="logloss",
                        n_jobs=1,
                        random_state=17,
                        verbosity=0,
                    ),
                ]
                probabilities = []
                predictions = []
                test_x = [training_x[i] for i in test_rows]
                for fold_model in fold_models:
                    fold_model.fit(fold_x, fold_y)
                    probabilities.append(fold_model.predict_proba(test_x)[:, 1])
                    predictions.append(fold_model.predict(test_x))
                ensemble_probabilities = [
                    (float(logistic) + float(tree)) / 2
                    for logistic, tree in zip(probabilities[0], probabilities[1])
                ]
                ensemble_predictions = [
                    int(logistic == 1 or tree == 1)
                    for logistic, tree in zip(predictions[0], predictions[1])
                ]
                labels = [training_y[i] for i in test_rows]
                fold_accuracies.append(float(accuracy_score(labels, ensemble_predictions)))
                fold_brier_scores.append(float(brier_score_loss(labels, ensemble_probabilities)))
            if fold_accuracies:
                rolling_origin = {
                    "folds": len(fold_accuracies),
                    "accuracy": round(mean(fold_accuracies), 3),
                    "brier_score": round(mean(fold_brier_scores), 3),
                }
        except ImportError:
            pass
    model = None
    if len(training_x) >= 20 and len(set(training_y)) == 2:
        try:
            from sklearn.linear_model import LogisticRegression

            model = LogisticRegression(class_weight="balanced", max_iter=500, random_state=17)
            model.fit(training_x, training_y)
        except ImportError:
            model = None
    tree_model = None
    if len(training_x) >= 30 and len(set(training_y)) == 2:
        try:
            from xgboost import XGBClassifier

            tree_model = XGBClassifier(
                n_estimators=80,
                max_depth=2,
                learning_rate=0.05,
                eval_metric="logloss",
                n_jobs=1,
                random_state=17,
                verbosity=0,
            )
            tree_model.fit(training_x, training_y)
        except ImportError:
            tree_model = None

    results = []
    for topic in topics:
        history = histories[topic]
        marks = [mark for period in topic_marks[topic] for mark in period]
        recent = history[-3:]
        frequency = sum(history)
        baseline = 0.5 if not history else (
            0.50 * (sum(history) / len(history))
            + 0.35 * (sum(recent) / len(recent))
            + 0.15 * (0.5 if not history[-1] else 0.35)
        )
        estimated = baseline
        if model is not None:
            features = _features(history, topic_marks[topic], len(years), 1 / max(len(topics), 1))
            logistic_estimate = float(model.predict_proba([features])[0][1])
            if tree_model is not None:
                tree_estimate = float(tree_model.predict_proba([features])[0][1])
                estimated = 0.4 * baseline + 0.3 * logistic_estimate + 0.3 * tree_estimate
            else:
                estimated = 0.65 * baseline + 0.35 * logistic_estimate
        last_index = max((i for i, present in enumerate(history) if present), default=-1)
        gap = len(years) - 1 - last_index if last_index >= 0 else len(years)
        years_text = len(years)
        if frequency:
            detail = f"Appeared in {frequency} of {years_text} observed papers"
            detail += ", skipped the latest observed year" if history and history[-1] == 0 else ", appeared in the latest observed year"
        else:
            detail = "No historical appearances recorded; estimate uses a neutral baseline"
        if gap > 1:
            detail += f"; absent for {gap} papers"
        if marks:
            detail += f"; average {mean(marks):g} marks"
        results.append({
            "topic": topic,
            "probability": round(max(0.05, min(0.95, estimated)), 3),
            "probability_percent": round(max(0.05, min(0.95, estimated)) * 100, 1),
            "reasoning": detail,
            "observed_papers": years_text,
            "appearances": frequency,
            "gap": gap,
        })
    ranked_results = sorted(results, key=lambda row: row["probability"], reverse=True)
    for result in ranked_results:
        result["rolling_origin_evaluation"] = rolling_origin
    return ranked_results


def analyze_patterns(questions: list[Question], topics: list[str]) -> dict:
    years = sorted({question.year for question in questions if question.year is not None})
    all_topics = list(dict.fromkeys(topics + [question.topic for question in questions]))
    matrix = []
    topic_stats = []
    for topic in all_topics:
        row = {"topic": topic}
        appearances = 0
        marks = []
        for year in years:
            asked = [q for q in questions if q.year == year and q.topic == topic]
            row[str(year)] = bool(asked)
            appearances += bool(asked)
            marks.extend(q.marks for q in asked if q.marks is not None)
        latest_index = max((index for index, year in enumerate(years) if any(q.year == year and q.topic == topic for q in questions)), default=-1)
        topic_stats.append({
            "topic": topic,
            "appearances": appearances,
            "frequency": round(appearances / len(years), 3) if years else 0,
            "gap": len(years) - 1 - latest_index if latest_index >= 0 else len(years),
            "average_marks": round(mean(marks), 2) if marks else None,
        })
        matrix.append(row)
    type_mix = defaultdict(int)
    difficulty_trend = defaultdict(lambda: defaultdict(int))
    marks_distribution = defaultdict(int)
    for question in questions:
        type_mix[question.question_type] += 1
        if question.year is not None:
            difficulty_trend[str(question.year)][question.difficulty] += 1
        if question.marks is not None:
            marks_distribution[str(question.marks)] += 1
    return {
        "years": years,
        "topic_matrix": matrix,
        "topic_stats": topic_stats,
        "question_type_mix": dict(type_mix),
        "difficulty_trend": {year: dict(values) for year, values in difficulty_trend.items()},
        "marks_distribution": dict(marks_distribution),
        "total_questions": len(questions),
    }
