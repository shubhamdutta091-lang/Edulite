import io
import os
import re
import shutil
import zipfile
from collections import Counter
from functools import lru_cache
from pathlib import Path

from backend.config import settings


SUPPORTED_TYPES = {
    ".pdf",
    ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff",
    ".txt", ".md", ".markdown", ".docx",
}
SUPPORTED_FORMATS_LABEL = "PDF, DOCX, TXT, Markdown, PNG, JPG, WEBP, BMP, and TIFF"
MAX_DOCX_UNCOMPRESSED_BYTES = 50 * 1024 * 1024
QUESTION_START = re.compile(
    r"(?im)^\s*(?:(?:question\s+\d{1,3}|q\s*\d{1,3})(?:\s*(?:\([a-zivx]+\)|[.)]))?|\d{1,3}\s*(?:\([a-z]\)|[.)])|\([a-zivx]{1,6}\))\s+"
)


def extract_text(filename: str, content: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix not in SUPPORTED_TYPES:
        raise ValueError(f"Unsupported file type '{suffix or 'unknown'}'. Supported formats: {SUPPORTED_FORMATS_LABEL}.")
    if suffix in {".txt", ".md", ".markdown"}:
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError("The text file must be UTF-8 encoded. Save it as UTF-8 and upload again.") from exc
    elif suffix == ".pdf":
        text = _extract_pdf(content)
    elif suffix == ".docx":
        text = _extract_docx(content)
    else:
        text = _ocr_image(content)
    cleaned = re.sub(r"(?m)^\s*(?:page\s*)?\d{1,3}\s*$", "", text, flags=re.IGNORECASE)
    cleaned = re.sub(r"(?m)^\s*(?:time allowed|maximum marks|instructions to candidates)\b.*$", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
    if suffix in {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"} and not cleaned:
        raise ValueError(
            "No readable text was found in this scan. Use a sharper, well-lit image with the full page visible, "
            "or upload a text-based PDF or DOCX."
        )
    return cleaned


def _configure_tesseract(pytesseract) -> None:
    candidates = []
    configured = (os.environ.get("TESSERACT_CMD") or settings.tesseract_cmd).strip().strip('"')
    if configured:
        candidates.append(Path(configured))
    available = shutil.which("tesseract")
    if available:
        candidates.append(Path(available))
    if os.name == "nt":
        candidates.extend([
            Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe",
            Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Tesseract-OCR" / "tesseract.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Tesseract-OCR" / "tesseract.exe",
        ])
    executable = next((candidate for candidate in candidates if candidate.is_file()), None)
    if executable is None:
        raise RuntimeError(
            "The Tesseract OCR engine is not installed or could not be found. On Windows, install it with "
            "`winget install --id UB-Mannheim.TesseractOCR -e --source winget`, then restart EduLite. "
            "If installed in a custom folder, set the TESSERACT_CMD environment variable to the full "
            "path of tesseract.exe."
        )
    pytesseract.pytesseract.tesseract_cmd = str(executable)


def _extract_docx(content: bytes) -> str:
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            entries = archive.infolist()
            if (
                len(entries) > 2000
                or sum(entry.file_size for entry in entries) > MAX_DOCX_UNCOMPRESSED_BYTES
                or "word/document.xml" not in archive.namelist()
            ):
                raise ValueError("The Word document is invalid or too large to safely process.")
    except zipfile.BadZipFile as exc:
        raise ValueError("The Word document is damaged or is not a valid .docx file.") from exc

    try:
        from docx import Document
        from docx.oxml.table import CT_Tbl
        from docx.oxml.text.paragraph import CT_P
        from docx.table import Table
        from docx.text.paragraph import Paragraph
    except ImportError as exc:
        raise RuntimeError("Word document support is unavailable. Install the backend requirements.") from exc

    try:
        document = Document(io.BytesIO(content))
        blocks = []
        for element in document.element.body.iterchildren():
            if isinstance(element, CT_P):
                paragraph = Paragraph(element, document).text.strip()
                if paragraph:
                    blocks.append(paragraph)
            elif isinstance(element, CT_Tbl):
                table = Table(element, document)
                for row in table.rows:
                    cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                    if cells:
                        blocks.append(" ".join(cells))
        return "\n".join(blocks)
    except Exception as exc:
        raise ValueError(f"Could not read the Word document: {exc}") from exc


def _extract_pdf(content: bytes) -> str:
    try:
        import pymupdf
    except ImportError as exc:
        raise RuntimeError("PDF support is unavailable. Install the backend requirements.") from exc
    try:
        document = pymupdf.open(stream=content, filetype="pdf")
        if document.page_count > 200:
            raise ValueError("The PDF has more than 200 pages. Split it into smaller papers before uploading.")
        pages = [page.get_text("text") for page in document]
        edge_lines = Counter()
        for page_text in pages:
            lines = [line.strip() for line in page_text.splitlines() if line.strip()]
            edge_lines.update(set(lines[:3] + lines[-3:]))
        repeated_headers = {line for line, count in edge_lines.items() if count >= 2}
        pages = [
            "\n".join(line for line in page_text.splitlines() if line.strip() not in repeated_headers)
            for page_text in pages
        ]
        text = "\n".join(pages).strip()
        if len(text) > 50:
            return text
        return _ocr_pdf(document)
    except Exception as exc:
        raise ValueError(f"Could not read the PDF: {exc}") from exc


def _ocr_pdf(document) -> str:
    try:
        import pymupdf
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Scanned PDF OCR requires PyMuPDF and Pillow from the backend requirements.") from exc
    pages = []
    try:
        for page in document:
            pixmap = page.get_pixmap(matrix=pymupdf.Matrix(2, 2), alpha=False)
            image = Image.open(io.BytesIO(pixmap.tobytes("png")))
            pages.append(_image_to_text(image))
    except Exception as exc:
        raise RuntimeError(f"OCR could not process a scanned PDF page: {exc}") from exc
    return "\n".join(pages)


@lru_cache(maxsize=1)
def _rapidocr_engine():
    try:
        from rapidocr import RapidOCR
    except ImportError as exc:
        raise RuntimeError(
            "The built-in OCR fallback is unavailable. Install the project requirements with "
            "`python -m pip install -r requirements.txt`."
        ) from exc
    return RapidOCR()


def _rapidocr_image_to_string(image) -> str:
    try:
        result = _rapidocr_engine()(image)
    except Exception as exc:
        raise RuntimeError(f"The built-in OCR engine could not read the page: {exc}") from exc
    return "\n".join(text.strip() for text in (result.txts or ()) if text and text.strip())


def _image_to_text(image) -> str:
    try:
        import pytesseract

        _configure_tesseract(pytesseract)
        return pytesseract.image_to_string(image, config="--oem 3 --psm 6")
    except Exception as tesseract_error:
        try:
            return _rapidocr_image_to_string(image)
        except RuntimeError as rapidocr_error:
            raise RuntimeError(
                f"Tesseract OCR could not be used ({tesseract_error}); the built-in RapidOCR fallback also failed "
                f"({rapidocr_error}). Install the backend requirements and ensure the first-run model download "
                "can access the internet."
            ) from rapidocr_error


def _ocr_image(content: bytes) -> str:
    try:
        from PIL import Image, ImageOps
    except ImportError as exc:
        raise RuntimeError("Image OCR requires Pillow from the backend requirements.") from exc
    try:
        pages = []
        with Image.open(io.BytesIO(content)) as source:
            if getattr(source, "n_frames", 1) > 200:
                raise ValueError("The image contains more than 200 pages. Split it into smaller files before uploading.")
            for frame_index in range(getattr(source, "n_frames", 1)):
                source.seek(frame_index)
                image = ImageOps.exif_transpose(source.copy()).convert("RGB")
                if image.width * image.height > 40_000_000:
                    raise ValueError("An image page is larger than 40 megapixels. Resize it before uploading.")
                image = ImageOps.autocontrast(image.convert("L"))
                image.thumbnail((3600, 3600))
                image = image.point(lambda pixel: 255 if pixel > 155 else 0)
                pages.append(_image_to_text(image))
        return "\n".join(pages)
    except ValueError:
        raise
    except Exception as exc:
        raise RuntimeError(f"OCR could not process the image with Tesseract or RapidOCR: {exc}") from exc


def split_questions(text: str, filename: str) -> tuple[list[dict], int | None]:
    year_match = re.search(r"\b(19\d{2}|20\d{2}|21\d{2})\b", filename + "\n" + text)
    year = int(year_match.group(1)) if year_match else None
    matches = list(QUESTION_START.finditer(text))
    chunks = []
    if matches:
        for index, match in enumerate(matches):
            end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
            chunk = text[match.start():end].strip()
            if len(chunk) >= 10:
                chunks.append(chunk)
    else:
        chunks = [part.strip() for part in re.split(r"\n\s*\n", text) if len(part.strip()) >= 18]
    result = []
    for chunk in chunks[:300]:
        marks_match = re.search(r"\[\s*(\d+(?:\.\d+)?)\s*marks?\s*\]|\(\s*(\d+(?:\.\d+)?)\s*marks?\s*\)", chunk, re.I)
        if marks_match:
            marks = float(next(value for value in marks_match.groups() if value is not None))
        else:
            marks = None
        cleaned = re.sub(r"\s+", " ", chunk).strip()
        result.append({"text": cleaned[:10_000], "marks": marks, "year": year, "confidence": 0.78 if matches else 0.48})
    return result, year
