# Sample data

The reproducible synthetic PYQ examples are defined in [`backend/seed.py`](../backend/seed.py). Run `python -m backend.seed` to create the built-in subjects and sample questions in the configured database. Generated database files are intentionally ignored by Git; no student uploads or credentials are stored in this folder.
